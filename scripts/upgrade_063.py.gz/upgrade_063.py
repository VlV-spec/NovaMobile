#!/usr/bin/env python3
"""Nova Mobile 0.6.3: independent four-slot Dock, deterministic persistence, testable logic."""
from pathlib import Path

root = Path('.')
p = root/'app/src/main/java/com/novahome/mobile/MainActivity.kt'
s = p.read_text('utf-8')

def patch(before: str, after: str):
    global s
    count = s.count(before)
    if count != 1:
        raise RuntimeError(f'Expected 1 match, got {count}: {before[:90]!r}')
    s = s.replace(before, after, 1)

# Do not derive four Dock positions from the favorite list: each is an independent slot.
start = s.index('            val dockPackages = remember {')
end = s.index('            fun openApps(edit: Boolean = false) {', start)
s = s[:start] + '''            val validPackages = remember(apps) { apps.map { it.packageName }.toSet() }
            val dockSlots = remember {
                mutableStateListOf<String>().apply {
                    addAll(DockLogic.restore(
                        prefs.getString("dock_slots_v063", null),
                        prefs.getString("dock_apps", null),
                        favorites.toList(), validPackages
                    ))
                }
            }
            fun persistLayout() {
                prefs.edit()
                    .putString("favorites", favorites.joinToString("|"))
                    .putString("dock_slots_v063", DockLogic.encode(dockSlots))
                    .putString("dock_apps", dockSlots.filter { it.isNotBlank() }.joinToString("|"))
                    .apply()
            }
            fun setDock(next: List<String>) {
                if (next == dockSlots.toList()) return
                dockSlots.clear()
                dockSlots.addAll(next)
                persistLayout()
            }
            fun toggleFavorite(pkg: String) {
                if (pkg in favorites) favorites.remove(pkg) else favorites.add(pkg)
                // Changing favorites must never silently change the Dock.
                persistLayout()
            }
            fun replaceDockSlot(slot: Int, pkg: String) {
                if (slot !in 0..3 || pkg !in validPackages) return
                if (pkg !in favorites) favorites.add(pkg)
                setDock(DockLogic.replace(dockSlots.toList(), slot, pkg))
                persistLayout()
                Toast.makeText(this, "Dock ${slot + 1}: закреплено", Toast.LENGTH_SHORT).show()
            }
            fun clearDockSlot(slot: Int) {
                if (slot !in 0..3) return
                val removed = dockSlots[slot]
                if (removed.isBlank()) return
                if (removed !in favorites) favorites.add(removed)
                setDock(DockLogic.remove(dockSlots.toList(), slot))
                persistLayout()
                Toast.makeText(this, "Убрано из Dock ${slot + 1}", Toast.LENGTH_SHORT).show()
            }
            fun toggleDock(pkg: String) {
                if (pkg !in validPackages) return
                if (pkg !in favorites) favorites.add(pkg)
                val before = dockSlots.toList()
                val existing = before.indexOf(pkg)
                val slot = if (existing >= 0) existing else before.indexOf("").takeIf { it >= 0 } ?: 3
                setDock(DockLogic.toggle(before, pkg))
                persistLayout()
                Toast.makeText(this, if (existing >= 0) "Убрано из Dock" else "Dock ${slot + 1}: закреплено", Toast.LENGTH_SHORT).show()
            }
''' + s[end:]
# Reordering must manipulate Dock slots, not favorites which are a separate collection.
start = s.index('            fun reorderFavorites(from: String, to: String) {')
end = s.index('            var clockEnabled by remember {', start)
s = s[:start] + '''            fun reorderFavorites(from: String, to: String) {
                if (from == to) return
                val dockFrom = dockSlots.indexOf(from)
                val dockTo = dockSlots.indexOf(to)
                when {
                    dockFrom >= 0 -> replaceDockSlot(dockFrom, to)
                    dockTo >= 0 -> replaceDockSlot(dockTo, from)
                    else -> {
                        val source = favorites.indexOf(from)
                        val target = favorites.indexOf(to)
                        if (source < 0 || target < 0) return
                        favorites[source] = to
                        favorites[target] = from
                        persistLayout()
                    }
                }
            }
''' + s[end:]
patch('''            val dock = dockPackages.mapNotNull { pkg -> apps.find { it.packageName == pkg } }
            val dockSet = dockPackages.toSet()
''','''            val dock = dockSlots.map { pkg -> apps.find { it.packageName == pkg } }
            val dockSet = dockSlots.filter { it.isNotBlank() }.toSet()
''')
patch('''                            dockPackages = dockPackages, onDock = { toggleDock(it) }
''','''                            dockPackages = dockSlots.filter { it.isNotBlank() }, onDock = { toggleDock(it) }
''')
patch('''                            onDockSlot = { dockEditSlot = it },
                            onSystemSettings =''','''                            onDockSlot = { dockEditSlot = it },
                            onDockRemove = { clearDockSlot(it) },
                            onSystemSettings =''')
patch('''    dock: List<InstalledApp>,
''','''    dock: List<InstalledApp?>,
''')
patch('''    onDockSlot: (Int) -> Unit,
    onSystemSettings: () -> Unit
''','''    onDockSlot: (Int) -> Unit,
    onDockRemove: (Int) -> Unit,
    onSystemSettings: () -> Unit
''')
patch('''            Text("${dock.size + shortcuts.size}", color = WhiteMuted, fontSize = 12.sp)
''','''            Text("${dock.count { it != null } + shortcuts.size}", color = WhiteMuted, fontSize = 12.sp)
''')
start=s.index('            dock.forEachIndexed { index, app ->')
end=s.index('            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterHorizontally)',start) if '            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterHorizontally)' in s[start:] else s.index('            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {\n                Box(Modifier.size(47.dp)',start)
s=s[:start]+'''            // Precisely four independent and clickable positions, including empty slots.
            // No long-press detector here: it swallowed Dock taps in previous previews.
            dock.forEachIndexed { index, app ->
                Column(
                    Modifier.weight(1f).padding(horizontal = 1.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.fillMaxWidth().height(52.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(if (arranging) accent.copy(alpha = .11f) else Color.Transparent)
                            .border(if (arranging) 1.dp else 0.dp,
                                accent.copy(alpha = .40f), RoundedCornerShape(15.dp))
                            .clickable {
                                if (arranging || app == null) onDockSlot(index)
                                else onLaunch(app)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (app != null) AppIcon(app, 43)
                        else Text("+", color = accent, fontSize = 27.sp)
                    }
                    if (arranging) {
                        Text(if (app == null) "Добавить" else "Заменить",
                            color = accent, fontSize = 9.sp, maxLines = 1,
                            modifier = Modifier.clickable { onDockSlot(index) }
                                .padding(top = 5.dp, bottom = 2.dp))
                        if (app != null) {
                            Text("Убрать", color = Rose, fontSize = 9.sp, maxLines = 1,
                                modifier = Modifier.clickable { onDockRemove(index) }
                                    .padding(horizontal = 2.dp, vertical = 4.dp))
                        }
                    }
                }
            }
''' +s[end:]
patch('''                        selectedApp == null -> "Dock: нажми на значок внизу, чтобы заменить или убрать его"''','''                        selectedApp == null -> "В Dock нажми «Заменить» или «Убрать» под иконкой"''')
patch('''Text("Nova Mobile 0.6.2 · Dock Editor Preview"''','''Text("Nova Mobile 0.6.3 · Fixed Dock Slots Preview"''')
patch('''                    if (dockEditSlot >= 0) {
''','''                    if (dockEditSlot in 0..3) {
''')
p.write_text(s, 'utf-8')

logic = root/'app/src/main/java/com/novahome/mobile/DockLogic.kt'
logic.write_text('''package com.novahome.mobile

/** Stable, testable Dock model, independent of Favorites and UI gestures. */
internal object DockLogic {
    const val SLOT_COUNT = 4
    private const val EMPTY = "~"

    fun normalize(raw: List<String>, installed: Set<String>): List<String> {
        val seen = mutableSetOf<String>()
        return (raw + List(SLOT_COUNT) { "" }).take(SLOT_COUNT).map { token ->
            val item = if (token == EMPTY) "" else token
            if (item.isNotBlank() && item in installed && seen.add(item)) item else ""
        }
    }

    fun restore(saved: String?, legacy: String?, favorites: List<String>, installed: Set<String>): List<String> {
        val raw = when {
            saved != null -> saved.split('|')
            legacy != null -> legacy.split('|')
            else -> favorites
        }
        return normalize(raw, installed)
    }

    fun encode(slots: List<String>): String {
        require(slots.size == SLOT_COUNT)
        return slots.joinToString("|") { it.ifEmpty { EMPTY } }
    }

    fun replace(slots: List<String>, slot: Int, pkg: String): List<String> {
        require(slots.size == SLOT_COUNT && slot in 0 until SLOT_COUNT && pkg.isNotBlank())
        val copy = slots.toMutableList()
        val previous = copy[slot]
        val other = copy.indexOf(pkg)
        if (other == slot) return copy
        if (other >= 0) copy[other] = previous
        copy[slot] = pkg
        return copy
    }

    fun remove(slots: List<String>, slot: Int): List<String> {
        require(slots.size == SLOT_COUNT && slot in 0 until SLOT_COUNT)
        return slots.toMutableList().apply { this[slot] = "" }
    }

    fun toggle(slots: List<String>, pkg: String): List<String> {
        require(slots.size == SLOT_COUNT && pkg.isNotBlank())
        val existing = slots.indexOf(pkg)
        if (existing >= 0) return remove(slots, existing)
        val available = slots.indexOf("")
        return replace(slots, if (available >= 0) available else SLOT_COUNT - 1, pkg)
    }
}
''', 'utf-8')

build=root/'app/build.gradle.kts'
b=build.read_text('utf-8')
assert 'applicationId = "com.novahome.mobile.dockeditorpreview"' in b
assert 'versionName = "0.6.2-preview"' in b
b=b.replace('applicationId = "com.novahome.mobile.dockeditorpreview"',
            'applicationId = "com.novahome.mobile.fixedslotspreview"')
b=b.replace('versionCode = 9', 'versionCode = 10')
b=b.replace('versionName = "0.6.2-preview"', 'versionName = "0.6.3-preview"')
if 'testImplementation("junit:junit:4.13.2")' not in b:
    b=b.replace('dependencies {', 'dependencies {\n    testImplementation("junit:junit:4.13.2")')
build.write_text(b, 'utf-8')

manifest=root/'app/src/main/AndroidManifest.xml'
m=manifest.read_text('utf-8')
assert 'android:label="Nova Mobile 0.6.2"' in m
manifest.write_text(m.replace('android:label="Nova Mobile 0.6.2"','android:label="Nova Mobile 0.6.3"'), 'utf-8')

unit=root/'app/src/test/java/com/novahome/mobile/DockLogicTest.kt'
unit.parent.mkdir(parents=True, exist_ok=True)
unit.write_text('''package com.novahome.mobile

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DockLogicTest {
    private val full = listOf("phone", "camera", "chrome", "youtube")
    private val known = setOf("phone", "camera", "chrome", "youtube", "maps", "telegram")

    @Test fun replaceOccupiedSlotKeepsFourStablePositions() {
        assertEquals(listOf("phone", "maps", "chrome", "youtube"), DockLogic.replace(full, 1, "maps"))
    }

    @Test fun removingLeavesBlankInSamePosition() {
        assertEquals(listOf("phone", "", "chrome", "youtube"), DockLogic.remove(full, 1))
    }

    @Test fun pinFromDrawerFillsFirstEmptyPlace() {
        val afterRemove = DockLogic.remove(full, 1)
        assertEquals(listOf("phone", "telegram", "chrome", "youtube"), DockLogic.toggle(afterRemove, "telegram"))
    }

    @Test fun swapTwoExistingPinnedAppsWithoutDuplicate() {
        val result = DockLogic.replace(full, 0, "chrome")
        assertEquals(listOf("chrome", "camera", "phone", "youtube"), result)
        assertEquals(4, result.toSet().size)
    }

    @Test fun unpinDoesNotShiftNeighbors() {
        assertEquals(listOf("phone", "camera", "", "youtube"), DockLogic.toggle(full, "chrome"))
    }

    @Test fun roundTripPreservesEmptySlotsAfterRestart() {
        val slots = listOf("", "camera", "", "youtube")
        assertEquals(slots, DockLogic.restore(DockLogic.encode(slots), null, emptyList(), known))
    }

    @Test fun legacyMigratesAndFiltersUninstalledApps() {
        assertEquals(listOf("phone", "camera", "", ""),
            DockLogic.restore(null, "phone|camera|removed|phone", emptyList(), known))
    }

    @Test fun removeThenInsertMovesAppBackIntoSameEmptyPosition() {
        val without = DockLogic.remove(full, 0)
        assertEquals(full, DockLogic.replace(without, 0, "phone"))
    }
}
''','utf-8')
print('Nova Mobile 0.6.3: generated independent 4-slot Dock and eight unit tests')
