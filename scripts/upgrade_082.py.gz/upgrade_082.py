#!/usr/bin/env python3
"""Nova Mobile 0.8.2: polish Dock dialog, app drawer, settings surfaces.
Keeps Dock persistence, selection and home geometry unchanged.
"""
from pathlib import Path
p=Path('app/src/main/java/com/novahome/mobile/MainActivity.kt')
s=p.read_text('utf-8')
def patch(old,new):
    global s
    n=s.count(old)
    if n!=1: raise RuntimeError(f'Expected one occurrence, found {n}: {old[:75]!r}')
    s=s.replace(old,new,1)
patch('''                Text("${apps.size} установлено", color = WhiteMuted, fontSize = 11.sp)''','''                Text("${apps.size} установлено · NOVA ULTRA", color = WhiteMuted, fontSize = 11.sp)''')
patch('''            placeholder = { Text("Быстрый поиск", color = WhiteMuted) },
            leadingIcon = { Text("⌕", color = accent, fontSize = 25.sp) },''','''            placeholder = { Text("Найти приложение", color = WhiteMuted) },
            leadingIcon = { Text("⌕", color = accent, fontSize = 25.sp) },
            trailingIcon = {
                if (search.isNotEmpty()) TextButton(onClick = { onSearch("") }) {
                    Text("✕", color = WhiteMuted, fontSize = 16.sp)
                }
            },''')
patch('''            shape = RoundedCornerShape(19.dp),''','''            shape = RoundedCornerShape(23.dp),''')
patch('''            Text("Нажми на плитку для избранного, а «+ Dock» — чтобы закрепить внизу. До 4 значков; новый заменяет последний.",''','''            Text("Касание иконки — избранное. «+ Dock» закрепляет приложение в свободном слоте или заменяет последний. Точное место меняется через «Редакт.» на главном экране.",''')
patch('''    val shape = RoundedCornerShape(13.dp)
    Box(Modifier.clip(shape)
        .background(if (selected) accent.copy(alpha = .19f) else Panel.copy(alpha = .75f))
        .border(1.dp, if (selected) accent.copy(alpha = .45f) else Color.White.copy(alpha = .07f), shape)
        .clickable(onClick = onClick)
        .padding(horizontal = 13.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {''','''    val shape = RoundedCornerShape(16.dp)
    Box(Modifier.clip(shape)
        .background(if (selected) accent.copy(alpha = .20f) else Color.White.copy(alpha = .035f))
        .border(1.dp, if (selected) accent.copy(alpha = .50f) else Color.White.copy(alpha = .09f), shape)
        .clickable(onClick = onClick)
        .padding(horizontal = 15.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {''')
patch('''            Text("Dock · место ${slot + 1}", color = Color.White, fontSize = 19.sp)''','''            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(14.dp))
                    .background(accent.copy(alpha = .18f))
                    .border(1.dp, accent.copy(alpha = .30f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center) {
                    Text("${slot + 1}", color = accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Настройка Dock", color = Color.White, fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold)
                    Text("Ячейка ${slot + 1} из 4", color = WhiteMuted, fontSize = 11.sp)
                }
            }''')
patch('''                Text("Выбери приложение — оно заменит значок именно в этом месте.",
                    color = WhiteMuted, fontSize = 12.sp)
                Spacer(Modifier.height(9.dp))
                OutlinedTextField(value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Поиск приложения") })
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listItems(matches, key = { it.packageName }) { app ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .clickable { onSelect(app.packageName) }
                                .padding(horizontal = 7.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(app, 38)
                            Spacer(Modifier.width(10.dp))
                            Text(app.label, color = Color.White, fontSize = 13.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f))
                            Text("+", color = accent, fontSize = 21.sp)
                        }
                    }
                }''','''                Text("Коснись приложения — оно займёт выбранное место в Dock.",
                    color = WhiteMuted, fontSize = 12.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Поиск приложения") },
                    leadingIcon = { Text("⌕", color = accent, fontSize = 23.sp) },
                    trailingIcon = {
                        if (query.isNotEmpty()) TextButton(onClick = { query = "" }) {
                            Text("✕", color = WhiteMuted)
                        }
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = accent.copy(alpha = .7f),
                        unfocusedBorderColor = Color.White.copy(alpha = .13f),
                        focusedContainerColor = Background,
                        unfocusedContainerColor = Background
                    ))
                Spacer(Modifier.height(10.dp))
                if (matches.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(85.dp), contentAlignment = Alignment.Center) {
                        Text("Ничего не найдено", color = WhiteMuted, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 330.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        listItems(matches, key = { it.packageName }) { app ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                    .background(Color.White.copy(alpha = .035f))
                                    .border(1.dp, Color.White.copy(alpha = .07f), RoundedCornerShape(18.dp))
                                    .clickable { onSelect(app.packageName) }
                                    .padding(horizontal = 11.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIcon(app, 43)
                                Spacer(Modifier.width(12.dp))
                                Text(app.label, color = Color.White, fontSize = 14.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f))
                                Box(Modifier.size(28.dp).clip(RoundedCornerShape(10.dp))
                                    .background(accent.copy(alpha = .16f)),
                                    contentAlignment = Alignment.Center) {
                                    Text("+", color = accent, fontSize = 20.sp)
                                }
                            }
                        }
                    }
                }''')
patch('''            TextButton(onClick = onDismiss) { Text("Закрыть", color = accent) }''','''            TextButton(onClick = onDismiss) { Text("Готово", color = accent) }''')
patch('''            TextButton(onClick = onRemove) { Text("Убрать из Dock", color = Rose, fontSize = 12.sp) }''','''            TextButton(onClick = onRemove) { Text("Убрать", color = Rose, fontSize = 13.sp) }''')
patch('''        containerColor = Panel
    )''','''        containerColor = Color(0xFF171A27),
        shape = RoundedCornerShape(30.dp)
    )''')
patch('''Text("Nova Mobile 0.8.1 · Layout Fix Preview"''','''Text("Nova Mobile 0.8.2 · Ultra Polish Preview"''')
p.write_text(s,encoding='utf-8')
b=Path('app/build.gradle.kts'); t=b.read_text('utf-8')
assert 'applicationId = "com.novahome.mobile.layoutfix081"' in t
assert 'versionName = "0.8.1-preview"' in t
t=t.replace('applicationId = "com.novahome.mobile.layoutfix081"','applicationId = "com.novahome.mobile.ultrapolish082"').replace('versionCode = 15','versionCode = 16').replace('versionName = "0.8.1-preview"','versionName = "0.8.2-preview"'); b.write_text(t,'utf-8')
m=Path('app/src/main/AndroidManifest.xml'); t=m.read_text('utf-8'); assert 'android:label="Nova Mobile 0.8.1"' in t; m.write_text(t.replace('android:label="Nova Mobile 0.8.1"','android:label="Nova Mobile 0.8.2"'),'utf-8')
print('Nova Mobile 0.8.2 Ultra Polish applied')
