#!/usr/bin/env python3
"""Nova Mobile 0.8.3 preview: weather and VPN status cards."""
from pathlib import Path
p=Path('app/src/main/java/com/novahome/mobile/MainActivity.kt')
s=p.read_text('utf-8')
def patch(a,b):
 global s
 n=s.count(a)
 if n != 1: raise RuntimeError(f'Expected unique anchor ({n}): {a[:80]!r}')
 s=s.replace(a,b,1)
# Replace promotional caption under big clock with tiny weather strip (also fits compact clock)
patch('''                if (!compactClock) {
                    Spacer(Modifier.height(15.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = .09f)))
                    Spacer(Modifier.height(12.dp))
                    Text("Стильный главный экран для Galaxy Ultra.", color = Color.White.copy(alpha = .54f), fontSize = 12.sp)
                }''','''                Spacer(Modifier.height(if (compactClock) 4.dp else 11.dp))
                UltraWeatherStrip(accent = accent)
''')
# Weather is nested, VPN shares existing widget row via horizontal scrolling.
patch('        if (showBatteryWidget || showCalendarWidget) {', '        run {')
patch('''            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                if (showBatteryWidget) {''','''            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                if (showBatteryWidget) {''')
# Width of existing two cards fixed so VPN fits via scroll even in 3-col layout.
assert s.count('Modifier.weight(1f).height(82.dp).clip(RoundedCornerShape(24.dp))') == 2
s=s.replace('Modifier.weight(1f).height(82.dp).clip(RoundedCornerShape(24.dp))', 'Modifier.width(156.dp).height(82.dp).clip(RoundedCornerShape(24.dp))')
patch('''                }
            }
        }
        if (arranging) {''','''                }
                UltraVpnCard(accent = accent)
            }
        }
        if (arranging) {''')
patch('Nova Mobile 0.8.2 · Ultra Polish Preview','Nova Mobile 0.8.3 · Weather & VPN Preview')
s=s.replace('import androidx.compose.foundation.verticalScroll\n', 'import androidx.compose.foundation.verticalScroll\nimport androidx.compose.foundation.horizontalScroll\n')
p.write_text(s,'utf-8')
b=Path('app/build.gradle.kts')
t=b.read_text('utf-8')
assert 'applicationId = "com.novahome.mobile.ultrapolish082"' in t, t
assert 'versionCode = 16' in t
assert 'versionName = "0.8.2-preview"' in t
t=t.replace('applicationId = "com.novahome.mobile.ultrapolish082"','applicationId = "com.novahome.mobile.status083"').replace('versionCode = 16','versionCode = 17').replace('versionName = "0.8.2-preview"','versionName = "0.8.3-preview"')
b.write_text(t,'utf-8')
m=Path('app/src/main/AndroidManifest.xml')
t=m.read_text('utf-8')
assert 'android:label="Nova Mobile 0.8.2"' in t
t=t.replace('android:label="Nova Mobile 0.8.2"','android:label="Nova Mobile 0.8.3"')
t=t.replace('<application ', '<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>\n    <application ',1)
m.write_text(t,'utf-8')
print('Nova 0.8.3 status cards prepared')
