package com.novahome.mobile

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.Socket
import java.net.InetSocketAddress
import java.net.URL
import kotlin.coroutines.resume
import kotlin.math.roundToInt

private data class CurrentWeather(val temperature: Int, val code: Int)

private suspend fun weatherForUser(context: Context): CurrentWeather? = withContext(Dispatchers.IO) {
    try {
        if (context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return@withContext null
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val last = runCatching { locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) }.getOrNull()
        val location: Location? = last ?: withTimeoutOrNull(8000L) {
            suspendCancellableCoroutine { continuation ->
                try {
                    locationManager.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, context.mainExecutor) { found ->
                        if (continuation.isActive) continuation.resume(found)
                    }
                } catch (_: Exception) {
                    if (continuation.isActive) continuation.resume(null)
                }
            }
        }
        if (location == null) return@withContext null
        // Only weather coordinates are sent; do not store a location history.
        val latitude = (location.latitude * 100).roundToInt() / 100.0
        val longitude = (location.longitude * 100).roundToInt() / 100.0
        val connection = URL("https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude&current=temperature_2m,weather_code&forecast_days=1").openConnection() as HttpURLConnection
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        try {
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() }).getJSONObject("current")
            CurrentWeather(json.getDouble("temperature_2m").roundToInt(), json.getInt("weather_code"))
        } finally { connection.disconnect() }
    } catch (_: Exception) { null }
}

private fun weatherCondition(code: Int): String = when (code) {
    0 -> "☀ Ясно"
    1, 2 -> "🌤 Облачно с прояснениями"
    3 -> "☁ Пасмурно"
    45, 48 -> "🌫 Туман"
    51, 53, 55, 56, 57 -> "🌦 Морось"
    61, 63, 65, 66, 67, 80, 81, 82 -> "🌧 Дождь"
    71, 73, 75, 77, 85, 86 -> "❄ Снег"
    95, 96, 99 -> "⛈ Гроза"
    else -> "🌡 Погода"
}

@Composable
fun UltraWeatherStrip(accent: Color) {
    val context = LocalContext.current
    var permitted by remember { mutableStateOf(context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) }
    var refreshed by remember { mutableIntStateOf(0) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permitted = granted
        if (granted) refreshed++
    }
    val result by produceState<CurrentWeather?>(initialValue = null, permitted, refreshed) {
        if (permitted) {
            while (true) {
                value = weatherForUser(context)
                delay(20 * 60 * 1000L)
            }
        }
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = .045f))
            .clickable {
                if (!permitted) permission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                else {
                    // Samsung Weather if installed, otherwise weather in the browser.
                    val launched = runCatching {
                        context.packageManager.getLaunchIntentForPackage("com.sec.android.daemonapp")?.let {
                            context.startActivity(it); true
                        } ?: false
                    }.getOrDefault(false)
                    if (!launched) runCatching {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=weather")))
                    }
                }
            }
            .padding(horizontal = 13.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("ПОГОДА", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(10.dp))
        val label = when {
            !permitted -> "Нажми, чтобы разрешить геопозицию"
            result == null -> "Нет данных · открыть погоду"
            else -> "${result!!.temperature}° · ${weatherCondition(result!!.code)}"
        }
        Text(label, color = Color.White.copy(alpha = .87f), fontSize = 11.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis)
    }
}

private data class VpnMetrics(val connected: Boolean, val totalKbps: Long, val delayMs: Long?)

private suspend fun tcpLatency(): Long? = withContext(Dispatchers.IO) {
    try {
        val start = SystemClock.elapsedRealtime()
        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1800) }
        SystemClock.elapsedRealtime() - start
    } catch (_: Exception) { null }
}

@Composable
fun UltraVpnCard(accent: Color) {
    val context = LocalContext.current
    val metrics by produceState(initialValue = VpnMetrics(false, 0, null)) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var previousBytes = -1L
        var previousAt = SystemClock.elapsedRealtime()
        var previousPing: Long? = null
        var checkedAt = 0L
        while (true) {
            val active = runCatching { cm.allNetworks.any {
                cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            } }.getOrDefault(false)
            val now = SystemClock.elapsedRealtime()
            val totals = TrafficStats.getTotalRxBytes() + TrafficStats.getTotalTxBytes()
            val valid = previousBytes >= 0 && totals >= 0 && now > previousAt
            val rate = if (valid) (((totals - previousBytes).coerceAtLeast(0) * 8L) / (now - previousAt)) else 0L
            previousBytes = totals
            previousAt = now
            if (active && now - checkedAt > 20000) {
                previousPing = tcpLatency()
                checkedAt = now
            }
            if (!active) previousPing = null
            value = VpnMetrics(active, rate, previousPing)
            delay(3000L)
        }
    }
    Column(
        Modifier.width(163.dp).height(82.dp).clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF12141F).copy(alpha = .93f))
            .border(1.dp, accent.copy(alpha = .23f), RoundedCornerShape(24.dp))
            .clickable { runCatching { context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) } }
            .padding(horizontal = 13.dp, vertical = 9.dp)
    ) {
        Text(if (metrics.connected) "● VPN АКТИВЕН" else "○ VPN НЕАКТИВЕН", color = if (metrics.connected) accent else Color.LightGray,
            fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(6.dp))
        Text("${metrics.totalKbps} кбит/с", color = Color.White, fontSize = 16.sp, maxLines = 1)
        Text("Трафик устройства · TCP ${metrics.delayMs?.let { "$it мс" } ?: "—"}",
            color = Color.White.copy(alpha = .62f), fontSize = 8.sp, maxLines = 1)
    }
}
