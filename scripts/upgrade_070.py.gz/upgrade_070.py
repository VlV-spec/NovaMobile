#!/usr/bin/env python3
"""Nova Mobile 0.7: lightweight built-in widgets and scrollable personalization settings.

Applies after upgrade_063.py.gz. Keeps DockLogic and gesture code unchanged.
"""
from pathlib import Path

source = Path('app/src/main/java/com/novahome/mobile/MainActivity.kt')
s = source.read_text('utf-8')

def patch(old: str, new: str, times: int = 1):
    global s
    actual = s.count(old)
    if actual != times:
        raise RuntimeError(f'Expected {times} matches, got {actual} for: {old[:100]!r}')
    s = s.replace(old, new, times)

patch('import androidx.compose.foundation.clickable\n',
      'import androidx.compose.foundation.clickable\nimport androidx.compose.foundation.rememberScrollState\nimport androidx.compose.foundation.verticalScroll\n')

# Keep a single persisted state owner for each widget setting.
patch('''            var clockEnabled by remember { mutableStateOf(prefs.getBoolean("clock_widget", true)) }
''', '''            var clockEnabled by remember { mutableStateOf(prefs.getBoolean("clock_widget", true)) }
            var compactClock by remember { mutableStateOf(prefs.getBoolean("clock_compact_v070", false)) }
            var batteryWidget by remember { mutableStateOf(prefs.getBoolean("widget_battery_v070", true)) }
            var calendarWidget by remember { mutableStateOf(prefs.getBoolean("widget_calendar_v070", true)) }
''')

patch('''                            showClock = clockEnabled,
                            wallpaperChosen =''', '''                            showClock = clockEnabled,
                            compactClock = compactClock,
                            showBatteryWidget = batteryWidget, showCalendarWidget = calendarWidget,
                            wallpaperChosen =''')

patch('''                            onShowClock = { clockEnabled = it; prefs.edit().putBoolean("clock_widget", it).apply() },
''', '''                            onShowClock = { clockEnabled = it; prefs.edit().putBoolean("clock_widget", it).apply() },
                            onCompactClock = { compactClock = it; prefs.edit().putBoolean("clock_compact_v070", it).apply() },
                            onBatteryWidget = { batteryWidget = it; prefs.edit().putBoolean("widget_battery_v070", it).apply() },
                            onCalendarWidget = { calendarWidget = it; prefs.edit().putBoolean("widget_calendar_v070", it).apply() },
''')

patch('''                            showClock = clockEnabled, onReorder =''', '''                            showClock = clockEnabled, compactClock = compactClock,
                            showBatteryWidget = batteryWidget, showCalendarWidget = calendarWidget,
                            onReorder =''')

patch('''    showClock: Boolean,
    onReorder: (String, String) -> Unit,''', '''    showClock: Boolean,
    compactClock: Boolean,
    showBatteryWidget: Boolean, showCalendarWidget: Boolean,
    onReorder: (String, String) -> Unit,''')

patch('''                    .padding(horizontal = 22.dp, vertical = 19.dp)
''', '''                    .padding(horizontal = 22.dp, vertical = if (compactClock) 12.dp else 19.dp)
''')
patch('''                Spacer(Modifier.height(8.dp))
                Text(time, color = Color.White, fontWeight = FontWeight.Light, fontSize = 70.sp, lineHeight = 75.sp)
                Text(date.replaceFirstChar { it.uppercase() }, color = WhiteMuted, fontSize = 14.sp)
                Spacer(Modifier.height(15.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = .09f)))
                Spacer(Modifier.height(12.dp))
                Text("Твой экран. Твои правила.", color = Color.White.copy(alpha = .51f), fontSize = 12.sp)
''', '''                Spacer(Modifier.height(if (compactClock) 3.dp else 8.dp))
                Text(time, color = Color.White, fontWeight = FontWeight.Light,
                    fontSize = if (compactClock) 48.sp else 70.sp,
                    lineHeight = if (compactClock) 53.sp else 75.sp)
                Text(date.replaceFirstChar { it.uppercase() }, color = WhiteMuted, fontSize = 14.sp)
                if (!compactClock) {
                    Spacer(Modifier.height(15.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = .09f)))
                    Spacer(Modifier.height(12.dp))
                    Text("Твой экран. Твои правила.", color = Color.White.copy(alpha = .51f), fontSize = 12.sp)
                }
''')

# Widget cards have no polling loop: reuse the existing 30-second home refresh.
patch('''        if (arranging) {
            Row(
''', '''        if (showBatteryWidget || showCalendarWidget) {
            val batteryPercentage = battery.removeSuffix("%").toIntOrNull()?.coerceIn(0, 100)
            val dayNumber = remember(now) { SimpleDateFormat("d", Locale("ru")).format(Date(now)) }
            val weekday = remember(now) { SimpleDateFormat("EEEE", Locale("ru")).format(Date(now)) }
            val monthName = remember(now) { SimpleDateFormat("LLLL", Locale("ru")).format(Date(now)) }
            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                if (showBatteryWidget) {
                    Column(
                        Modifier.weight(1f).height(78.dp).clip(RoundedCornerShape(20.dp))
                            .background(Panel.copy(alpha = .91f))
                            .border(1.dp, accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 13.dp, vertical = 11.dp)
                    ) {
                        Text("БАТАРЕЯ", color = accent, fontSize = 10.sp,
                            fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.height(5.dp))
                        Text(battery, color = Color.White, fontSize = 21.sp,
                            fontWeight = FontWeight.SemiBold, lineHeight = 23.sp)
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { (batteryPercentage ?: 0) / 100f },
                            modifier = Modifier.fillMaxWidth().height(3.dp),
                            color = accent, trackColor = Color.White.copy(alpha = .12f)
                        )
                    }
                }
                if (showCalendarWidget) {
                    Row(
                        Modifier.weight(1f).height(78.dp).clip(RoundedCornerShape(20.dp))
                            .background(Panel.copy(alpha = .91f))
                            .border(1.dp, accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 13.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(dayNumber, color = Color.White, fontSize = 35.sp,
                            fontWeight = FontWeight.Light)
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text(weekday.replaceFirstChar { it.uppercase() }, color = accent,
                                fontSize = 11.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            Text(monthName.replaceFirstChar { it.uppercase() }, color = WhiteMuted,
                                fontSize = 11.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        if (arranging) {
            Row(
''')

patch('''    showClock: Boolean, onShowClock: (Boolean) -> Unit,
''', '''    showClock: Boolean, onShowClock: (Boolean) -> Unit,
    compactClock: Boolean, onCompactClock: (Boolean) -> Unit,
    showBatteryWidget: Boolean, showCalendarWidget: Boolean,
    onBatteryWidget: (Boolean) -> Unit, onCalendarWidget: (Boolean) -> Unit,
''')

patch('''    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 14.dp)) {
''', '''    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(horizontal = 22.dp, vertical = 14.dp)) {
''')

patch('''        Spacer(Modifier.height(22.dp))
        Button(onClick = onEditFavorites''', '''        Spacer(Modifier.height(15.dp))
        WidgetSettingToggle("Компактные часы", "Оставить больше места под иконки",
            compactClock, onCompactClock)
        Spacer(Modifier.height(10.dp))
        WidgetSettingToggle("Виджет батареи", "Уровень заряда без лишних служб",
            showBatteryWidget, onBatteryWidget)
        Spacer(Modifier.height(10.dp))
        WidgetSettingToggle("Виджет даты", "Число, месяц и день недели",
            showCalendarWidget, onCalendarWidget)
        Spacer(Modifier.height(22.dp))
        Button(onClick = onEditFavorites''')

patch('''Text("Nova Mobile 0.6.3 · Fixed Dock Slots Preview"''',
      '''Text("Nova Mobile 0.7 · Native Widgets Preview"''')

patch('''Режим «Расставить»: удерживай значок и перетаскивай на другую иконку, в том числе в Dock. Можно также закрепить приложение через «Добавить» → «+ Dock». Два касания для обмена тоже работают.''',
      '''Встроенные виджеты батареи и календарной даты включаются в оформлении. Настоящие виджеты сторонних приложений добавим в отдельном релизе. Dock редактируется кнопками под каждой из четырёх ячеек.''')

# Composable extracted to reduce duplicated settings UI.
s += '''

@Composable
private fun WidgetSettingToggle(
    title: String, subtitle: String, enabled: Boolean, onToggle: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
            .background(Panel).clickable { onToggle(!enabled) }
            .padding(horizontal = 15.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text(subtitle, color = WhiteMuted, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Switch(checked = enabled, onCheckedChange = onToggle)
    }
}
'''
source.write_text(s, encoding='utf-8')

build = Path('app/build.gradle.kts')
b = build.read_text('utf-8')
assert 'applicationId = "com.novahome.mobile.fixedslotspreview"' in b
assert 'versionCode = 10' in b and 'versionName = "0.6.3-preview"' in b
b = b.replace('applicationId = "com.novahome.mobile.fixedslotspreview"',
              'applicationId = "com.novahome.mobile.widgets07preview"')
b = b.replace('versionCode = 10', 'versionCode = 11')
b = b.replace('versionName = "0.6.3-preview"', 'versionName = "0.7.0-preview"')
build.write_text(b, encoding='utf-8')

manifest = Path('app/src/main/AndroidManifest.xml')
m = manifest.read_text('utf-8')
assert 'android:label="Nova Mobile 0.6.3"' in m
manifest.write_text(m.replace('android:label="Nova Mobile 0.6.3"',
                              'android:label="Nova Mobile 0.7"'), encoding='utf-8')
print('Nova Mobile 0.7 native widgets: patch applied, DockLogic unchanged')
