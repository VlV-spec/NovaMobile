plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.novahome.mobile"
    compileSdk = 35

    defaultConfig {
        // Постоянный ID: больше никогда не меняй его, иначе каждая версия
        // будет ставиться отдельным приложением с пустыми настройками.
        applicationId = "com.novahome.mobile.glass09preview"
        minSdk = 29
        targetSdk = 35
        // Версия меняется только здесь.
        versionCode = 20
        versionName = "0.9.0-preview"
    }

    buildTypes {
        debug { }
        release { isMinifyEnabled = false }
    }

    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    testImplementation("junit:junit:4.13.2")
}
