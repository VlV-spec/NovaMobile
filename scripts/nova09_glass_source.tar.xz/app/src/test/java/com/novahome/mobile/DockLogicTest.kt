package com.novahome.mobile

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DockLogicTest {
    private val full = listOf("phone", "camera", "chrome", "youtube")
    private val known = setOf("phone", "camera", "chrome", "youtube", "maps", "telegram")

    @Test fun replaceOccupiedSlotKeepsFourStablePositions() {
        assertEquals(listOf("phone", "maps", "chrome", "youtube"), DockLogic.replace(full, 1, "maps"))
    }

    @Test fun removingLeavesBlankInSamePosition() {
        assertEquals(listOf("phone", "", "chrome", "youtube"), DockLogic.remove(full, 1))
    }

    @Test fun pinFromDrawerFillsFirstEmptyPlace() {
        val afterRemove = DockLogic.remove(full, 1)
        assertEquals(listOf("phone", "telegram", "chrome", "youtube"), DockLogic.toggle(afterRemove, "telegram"))
    }

    @Test fun swapTwoExistingPinnedAppsWithoutDuplicate() {
        val result = DockLogic.replace(full, 0, "chrome")
        assertEquals(listOf("chrome", "camera", "phone", "youtube"), result)
        assertEquals(4, result.toSet().size)
    }

    @Test fun unpinDoesNotShiftNeighbors() {
        assertEquals(listOf("phone", "camera", "", "youtube"), DockLogic.toggle(full, "chrome"))
    }

    @Test fun roundTripPreservesEmptySlotsAfterRestart() {
        val slots = listOf("", "camera", "", "youtube")
        assertEquals(slots, DockLogic.restore(DockLogic.encode(slots), null, emptyList(), known))
    }

    @Test fun legacyMigratesAndFiltersUninstalledApps() {
        assertEquals(listOf("phone", "camera", "", ""),
            DockLogic.restore(null, "phone|camera|removed|phone", emptyList(), known))
    }

    @Test fun removeThenInsertMovesAppBackIntoSameEmptyPosition() {
        val without = DockLogic.remove(full, 0)
        assertEquals(full, DockLogic.replace(without, 0, "phone"))
    }
}
