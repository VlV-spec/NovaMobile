package com.novahome.mobile

import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class InstalledApp(val label: String, val packageName: String, val activityName: String)

private data class Wallpapers(val sharp: ImageBitmap, val blurred: ImageBitmap)

class MainActivity : ComponentActivity() {

    /** Список приложений живёт здесь и обновляется при установке/удалении. */
    private var apps by mutableStateOf<List<InstalledApp>?>(null)

    /** Виден ли лаунчер. Фоновые циклы (погода, VPN, часы) работают только пока true. */
    private var launcherVisible by mutableStateOf(false)

    /** Увеличивается при нажатии «Домой», когда лаунчер уже открыт. */
    private var homePresses by mutableIntStateOf(0)

    private val launcherApps by lazy { getSystemService(LauncherApps::class.java) }

    private val packageCallback = object : LauncherApps.Callback() {
        override fun onPackageAdded(packageName: String, user: UserHandle) = reloadApps()
        override fun onPackageRemoved(packageName: String, user: UserHandle) = reloadApps()
        override fun onPackageChanged(packageName: String, user: UserHandle) {
            AppIconCache.evictPackage(packageName)
            reloadApps()
        }
        override fun onPackagesAvailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = reloadApps()
        override fun onPackagesUnavailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = reloadApps()
    }

    private fun reloadApps() {
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                runCatching {
                    launcherApps.getActivityList(null, Process.myUserHandle())
                        .filter { it.componentName.packageName != packageName }
                        .map { InstalledApp(it.label.toString(), it.componentName.packageName, it.componentName.className) }
                        .distinctBy { it.packageName }
                        .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
                }.getOrNull()
            }
            if (loaded != null) apps = loaded
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("nova", MODE_PRIVATE)
        launcherApps.registerCallback(packageCallback, Handler(Looper.getMainLooper()))
        reloadApps()
        setContent { NovaRoot(prefs) }
    }

    override fun onDestroy() {
        launcherApps.unregisterCallback(packageCallback)
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        launcherVisible = true
    }

    override fun onStop() {
        launcherVisible = false
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) homePresses++
    }

    // ------------------------------------------------------------------
    // Запуск приложений
    // ------------------------------------------------------------------

    private fun launch(app: InstalledApp) {
        val exact = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.packageName, app.activityName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        if (runCatching { startActivity(exact) }.isSuccess) return
        val fallback = runCatching {
            val intent = packageManager.getLaunchIntentForPackage(app.packageName) ?: return@runCatching false
            startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        }.getOrDefault(false)
        if (!fallback) Toast.makeText(this, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
    }

    // Сначала системное приложение по умолчанию, затем известные пакеты.
    private fun startFirstAvailable(intents: List<Intent>, preferredPackages: List<String>, label: String) {
        for (intent in intents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (runCatching { startActivity(intent) }.isSuccess) return
        }
        val fallback = preferredPackages.firstNotNullOfOrNull { pkg -> apps.orEmpty().find { it.packageName == pkg } }
        if (fallback != null) launch(fallback)
        else Toast.makeText(this, "Не найдено приложение: $label", Toast.LENGTH_SHORT).show()
    }

    private fun openAlarms() = startFirstAvailable(
        listOf(Intent(AlarmClock.ACTION_SHOW_ALARMS)),
        listOf("com.sec.android.app.clockpackage", "com.google.android.deskclock", "com.android.deskclock"),
        "Часы"
    )

    private fun openCalendar() = startFirstAvailable(
        listOf(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR),
            Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI)
        ),
        listOf("com.samsung.android.calendar", "com.google.android.calendar", "com.android.calendar"),
        "Календарь"
    )

    // ------------------------------------------------------------------
    // Корневой экран
    // ------------------------------------------------------------------

    @androidx.compose.runtime.Composable
    private fun NovaRoot(prefs: SharedPreferences) {
        val context = LocalContext.current
        val allApps = apps.orEmpty()

        var drawerOpen by remember { mutableStateOf(false) }
        var settingsOpen by remember { mutableStateOf(false) }
        var drawerEditing by remember { mutableStateOf(false) }
        var dockEditSlot by remember { mutableIntStateOf(-1) }

        var columns by remember { mutableIntStateOf(prefs.getInt("columns", 4).coerceIn(3, 5)) }
        val dynamicAvailable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        var palette by remember {
            mutableIntStateOf(prefs.getInt("palette", if (dynamicAvailable) PALETTE_SYSTEM else 0).coerceIn(0, PALETTE_SYSTEM))
        }
        val accent = if (palette == PALETTE_SYSTEM && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            remember(context) { dynamicDarkColorScheme(context).primary }
        } else themes[palette.coerceIn(0, themes.lastIndex)]

        var wallpaperUri by remember { mutableStateOf(prefs.getString("wallpaper_uri", "").orEmpty()) }
        var wallpaperShade by remember { mutableFloatStateOf(prefs.getFloat("wallpaper_shade", .30f).coerceIn(0f, .8f)) }
        val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                wallpaperUri = uri.toString()
                prefs.edit().putString("wallpaper_uri", wallpaperUri).apply()
            }
        }

        var clockEnabled by remember { mutableStateOf(prefs.getBoolean("clock_widget", true)) }
        var compactClock by remember { mutableStateOf(prefs.getBoolean("clock_compact", false)) }
        var batteryWidget by remember { mutableStateOf(prefs.getBoolean("widget_battery", true)) }
        var calendarWidget by remember { mutableStateOf(prefs.getBoolean("widget_calendar", true)) }

        // --- Избранное и Dock ----------------------------------------
        val favorites = remember {
            mutableStateListOf<String>().apply {
                addAll(prefs.getString("favorites", "").orEmpty().split("|").filter { it.isNotBlank() })
            }
        }
        val dockSlots = remember { mutableStateListOf("", "", "", "") }
        val validPackages = remember(allApps) { allApps.map { it.packageName }.toSet() }

        fun persistLayout() {
            prefs.edit()
                .putString("favorites", favorites.joinToString("|"))
                .putString("dock_slots", DockLogic.encode(dockSlots))
                .apply()
        }

        // Когда список приложений загружен или изменился: первичное избранное
        // и восстановление Dock (удалённые приложения из Dock пропадают).
        LaunchedEffect(validPackages) {
            if (validPackages.isEmpty()) return@LaunchedEffect
            if (!prefs.contains("favorites")) {
                val preferred = listOf(
                    "com.samsung.android.dialer", "org.telegram.messenger", "com.android.chrome",
                    "com.sec.android.app.camera", "com.google.android.youtube", "com.sec.android.gallery3d",
                    "com.google.android.gm", "com.google.android.apps.maps", "com.android.vending"
                )
                val suggested = (preferred.filter { it in validPackages } +
                    allApps.map { it.packageName }.filterNot { it in preferred }.take(8)).distinct().take(12)
                favorites.clear()
                favorites.addAll(suggested)
            }
            val restored = DockLogic.restore(prefs.getString("dock_slots", null), null, favorites.toList(), validPackages)
            if (restored != dockSlots.toList()) {
                dockSlots.clear()
                dockSlots.addAll(restored)
            }
            persistLayout()
        }

        fun setDock(next: List<String>) {
            if (next == dockSlots.toList()) return
            dockSlots.clear()
            dockSlots.addAll(next)
            persistLayout()
        }
        fun toggleFavorite(pkg: String) {
            if (pkg in favorites) favorites.remove(pkg) else favorites.add(pkg)
            persistLayout()
        }
        fun replaceDockSlot(slot: Int, pkg: String) {
            if (slot !in 0..3 || pkg !in validPackages) return
            if (pkg !in favorites) favorites.add(pkg)
            setDock(DockLogic.replace(dockSlots.toList(), slot, pkg))
            persistLayout()
        }
        fun clearDockSlot(slot: Int) {
            if (slot !in 0..3 || dockSlots[slot].isBlank()) return
            val removed = dockSlots[slot]
            if (removed !in favorites) favorites.add(removed)
            setDock(DockLogic.remove(dockSlots.toList(), slot))
        }
        fun toggleDock(pkg: String) {
            if (pkg !in validPackages) return
            if (pkg !in favorites) favorites.add(pkg)
            setDock(DockLogic.toggle(dockSlots.toList(), pkg))
            persistLayout()
        }
        fun reorderFavorites(from: String, to: String) {
            if (from == to) return
            val dockFrom = dockSlots.indexOf(from)
            val dockTo = dockSlots.indexOf(to)
            when {
                dockFrom >= 0 -> replaceDockSlot(dockFrom, to)
                dockTo >= 0 -> replaceDockSlot(dockTo, from)
                else -> {
                    val source = favorites.indexOf(from)
                    val target = favorites.indexOf(to)
                    if (source < 0 || target < 0) return
                    favorites[source] = to
                    favorites[target] = from
                    persistLayout()
                }
            }
        }

        val byPackage = remember(allApps) { allApps.associateBy { it.packageName } }
        val dock = dockSlots.map { byPackage[it] }
        val dockSet = dockSlots.filter { it.isNotBlank() }.toSet()
        val shortcuts = favorites.mapNotNull { byPackage[it] }.filterNot { it.packageName in dockSet }.take(16)

        // --- «Назад» и «Домой» ----------------------------------------
        // Лаунчер всегда перехватывает «Назад»: на главном экране просто ничего не делаем.
        BackHandler(enabled = true) {
            when {
                drawerOpen -> { drawerOpen = false; drawerEditing = false }
                settingsOpen -> settingsOpen = false
            }
        }
        LaunchedEffect(homePresses) {
            drawerOpen = false
            drawerEditing = false
            settingsOpen = false
            dockEditSlot = -1
        }

        // --- Обои: резкие + размытые для стекла ------------------------
        // Цвет темы важен только для обоев по умолчанию; фото не перечитываем при смене темы.
        val auroraKey = if (wallpaperUri.isBlank()) accent else null
        val wallpapers by produceState<Wallpapers?>(initialValue = null, wallpaperUri, auroraKey) {
            value = withContext(Dispatchers.Default) {
                val base: Bitmap = (if (wallpaperUri.isNotBlank()) {
                    withContext(Dispatchers.IO) { decodeWallpaper(context, Uri.parse(wallpaperUri)) }
                } else null) ?: auroraWallpaper(accent)
                Wallpapers(base.asImageBitmap(), blurredCopy(base).asImageBitmap())
            }
        }
        var rootSize by remember { mutableStateOf(IntSize.Zero) }
        val backdrop = remember(wallpapers, rootSize) {
            Backdrop(wallpapers?.sharp, wallpapers?.blurred, rootSize)
        }

        MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = NovaBackground, surface = NovaPanel)) {
            CompositionLocalProvider(LocalBackdrop provides backdrop, LocalLauncherVisible provides launcherVisible) {
                Box(Modifier.fillMaxSize().onSizeChanged { rootSize = it }) {
                    WallpaperLayer(wallpaperShade)

                    HomeScreen(
                        accent = accent, dock = dock, shortcuts = shortcuts, columns = columns,
                        showClock = clockEnabled, compactClock = compactClock,
                        showBatteryWidget = batteryWidget, showDate = calendarWidget,
                        homeSignal = homePresses,
                        onReorder = { from, to -> reorderFavorites(from, to) },
                        onSettings = { settingsOpen = true },
                        onAppDrawer = { drawerEditing = false; drawerOpen = true },
                        onLaunch = { launch(it) },
                        onEditFavorites = { drawerEditing = true; drawerOpen = true },
                        onDockSlot = { dockEditSlot = it },
                        onDockRemove = { clearDockSlot(it) },
                        onOpenAlarms = { openAlarms() },
                        onOpenCalendar = { openCalendar() }
                    )

                    AnimatedVisibility(
                        visible = drawerOpen,
                        enter = slideInVertically(tween(320)) { it / 5 } + fadeIn(tween(220)),
                        exit = slideOutVertically(tween(240)) { it / 6 } + fadeOut(tween(180))
                    ) {
                        AppDrawer(
                            apps = allApps, loading = apps == null,
                            favorites = favorites, accent = accent, columns = columns,
                            editing = drawerEditing,
                            onEdit = { drawerEditing = !drawerEditing },
                            onBack = { drawerOpen = false; drawerEditing = false },
                            onLaunch = { launch(it) },
                            onFavorite = { toggleFavorite(it) },
                            dockPackages = dockSet, onDock = { toggleDock(it) }
                        )
                    }

                    AnimatedVisibility(
                        visible = settingsOpen,
                        enter = slideInVertically(tween(300)) { it / 6 } + fadeIn(tween(200)),
                        exit = slideOutVertically(tween(220)) { it / 6 } + fadeOut(tween(160))
                    ) {
                        NovaSettings(
                            columns = columns, palette = palette, accent = accent,
                            dynamicAvailable = dynamicAvailable,
                            showClock = clockEnabled, compactClock = compactClock,
                            showBatteryWidget = batteryWidget, showDate = calendarWidget,
                            wallpaperChosen = wallpaperUri.isNotBlank(), wallpaperShade = wallpaperShade,
                            onChooseWallpaper = { wallpaperPicker.launch(arrayOf("image/*")) },
                            onClearWallpaper = {
                                wallpaperUri = ""
                                prefs.edit().remove("wallpaper_uri").apply()
                            },
                            onWallpaperShade = {
                                wallpaperShade = it
                                prefs.edit().putFloat("wallpaper_shade", it).apply()
                            },
                            onShowClock = { clockEnabled = it; prefs.edit().putBoolean("clock_widget", it).apply() },
                            onCompactClock = { compactClock = it; prefs.edit().putBoolean("clock_compact", it).apply() },
                            onBatteryWidget = { batteryWidget = it; prefs.edit().putBoolean("widget_battery", it).apply() },
                            onShowDate = { calendarWidget = it; prefs.edit().putBoolean("widget_calendar", it).apply() },
                            onColumns = { columns = it; prefs.edit().putInt("columns", it).apply() },
                            onPalette = { palette = it; prefs.edit().putInt("palette", it).apply() },
                            onSystemSettings = { runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) } },
                            onBack = { settingsOpen = false },
                            onEditFavorites = { settingsOpen = false; drawerEditing = true; drawerOpen = true }
                        )
                    }

                    if (dockEditSlot in 0..3) {
                        DockSlotDialog(
                            slot = dockEditSlot, apps = allApps, accent = accent,
                            onSelect = { pkg -> replaceDockSlot(dockEditSlot, pkg); dockEditSlot = -1 },
                            onRemove = { clearDockSlot(dockEditSlot); dockEditSlot = -1 },
                            onDismiss = { dockEditSlot = -1 }
                        )
                    }
                }
            }
        }
    }
}
