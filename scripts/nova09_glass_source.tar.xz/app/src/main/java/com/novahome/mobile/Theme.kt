package com.novahome.mobile

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle

internal val NovaBackground = Color(0xFF05060B)
internal val NovaPanel = Color(0xFF12141F)
internal val Purple = Color(0xFF9B8CFF)
internal val Cyan = Color(0xFF7EE7FF)
internal val Rose = Color(0xFFFF8CCF)
internal val WhiteMuted = Color(0xFFE6EAF7).copy(alpha = .70f)
internal val WhiteSoft = Color.White.copy(alpha = .92f)

internal val themes = listOf(Purple, Cyan, Rose)
internal val themeNames = listOf("Аметист", "Лёд", "Роза")

/** Индекс палитры «Система»: цвет берётся из обоев телефона (Material You). */
internal const val PALETTE_SYSTEM = 3

/** Лаунчер на экране: только тогда работают таймеры погоды, VPN и часов. */
internal val LocalLauncherVisible = compositionLocalOf { true }

/** Мягкая тень под текстом, чтобы подписи читались на любых обоях. */
internal val TextOnWallpaper = TextStyle(
    shadow = Shadow(color = Color.Black.copy(alpha = .55f), offset = Offset(0f, 1.5f), blurRadius = 8f)
)
