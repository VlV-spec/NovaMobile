package com.novahome.mobile

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
internal fun NovaSettings(
    columns: Int, palette: Int, accent: Color, dynamicAvailable: Boolean,
    showClock: Boolean, compactClock: Boolean, showBatteryWidget: Boolean, showDate: Boolean,
    wallpaperChosen: Boolean, wallpaperShade: Float,
    onChooseWallpaper: () -> Unit, onClearWallpaper: () -> Unit, onWallpaperShade: (Float) -> Unit,
    onShowClock: (Boolean) -> Unit, onCompactClock: (Boolean) -> Unit,
    onBatteryWidget: (Boolean) -> Unit, onShowDate: (Boolean) -> Unit,
    onColumns: (Int) -> Unit, onPalette: (Int) -> Unit,
    onSystemSettings: () -> Unit, onBack: () -> Unit, onEditFavorites: () -> Unit
) {
    val context = LocalContext.current
    Glass(Modifier.fillMaxSize(), shape = RectangleShape, dim = .45f, outline = false) {
        Column(
            Modifier.fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "←", color = Color.White, fontSize = 24.sp,
                    modifier = Modifier.clip(CircleShape).clickable(onClick = onBack).padding(10.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text("Настройки", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Light)
            }

            SectionTitle("Обои")
            Section {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionPill(if (wallpaperChosen) "Сменить фото" else "Выбрать фото", accent, primary = true,
                        modifier = Modifier.weight(1f), onClick = onChooseWallpaper)
                    if (wallpaperChosen) ActionPill("Сбросить", accent, primary = false, onClick = onClearWallpaper)
                }
                Text(
                    if (wallpaperChosen) "Затемнение: ${(wallpaperShade * 100).toInt()}%"
                    else "Без фото используется фон в цветах темы. Затемнение: ${(wallpaperShade * 100).toInt()}%",
                    color = WhiteMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 14.dp)
                )
                Slider(
                    value = wallpaperShade, onValueChange = onWallpaperShade, valueRange = 0f..0.8f,
                    colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent,
                        inactiveTrackColor = Color.White.copy(alpha = .18f))
                )
            }

            SectionTitle("Цвет")
            Section {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    val options = buildList {
                        themes.forEachIndexed { i, c -> add(Triple(i, c, themeNames[i])) }
                        if (dynamicAvailable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            add(Triple(PALETTE_SYSTEM, dynamicDarkColorScheme(context).primary, "Система"))
                        }
                    }
                    options.forEach { (index, color, name) ->
                        val selected = index == palette
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                .background(if (selected) Color.White.copy(alpha = .10f) else Color.Transparent)
                                .clickable { onPalette(index) }
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(34.dp).clip(CircleShape)
                                    .background(if (index == PALETTE_SYSTEM)
                                        Brush.sweepGradient(listOf(color, Cyan, Rose, color))
                                    else Brush.linearGradient(listOf(color, color)))
                                    .then(if (selected) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                            )
                            Text(name, color = if (selected) Color.White else WhiteMuted, fontSize = 12.sp,
                                modifier = Modifier.padding(top = 8.dp), maxLines = 1)
                        }
                    }
                }
                if (dynamicAvailable) {
                    Text("«Система» берёт цвет из обоев телефона, как в One UI.",
                        color = WhiteMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }

            SectionTitle("Сетка")
            Section {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(3, 4, 5).forEach { value ->
                        val chosen = columns == value
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                                .background(if (chosen) accent.copy(alpha = .30f) else Color.White.copy(alpha = .06f))
                                .clickable { onColumns(value) }.padding(vertical = 13.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("$value в ряд", color = if (chosen) Color.White else WhiteMuted, fontSize = 14.sp) }
                    }
                }
            }

            SectionTitle("Главный экран")
            Section {
                Toggle("Часы", "Крупное время, нажатие — будильники", showClock, accent, onShowClock)
                Toggle("Компактные часы", "Больше места под обои", compactClock, accent, onCompactClock)
                Toggle("Дата", "День недели и число, нажатие — календарь", showDate, accent, onShowDate)
                Toggle("Батарея", "Заряд в строке под часами", showBatteryWidget, accent, onBatteryWidget)
                Spacer(Modifier.height(6.dp))
                ActionPill("Выбрать приложения на экране", accent, primary = false,
                    modifier = Modifier.fillMaxWidth(), onClick = onEditFavorites)
            }

            Spacer(Modifier.height(14.dp))
            ActionPill("Настройки телефона", accent, primary = false, modifier = Modifier.fillMaxWidth(), onClick = onSystemSettings)

            Text("Nova 0.9 · Glass", color = WhiteMuted, fontSize = 12.sp,
                modifier = Modifier.padding(top = 22.dp, bottom = 12.dp).align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(), color = WhiteMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        letterSpacing = 1.2.sp, modifier = Modifier.padding(start = 6.dp, top = 22.dp, bottom = 8.dp)
    )
}

@Composable
private fun Section(content: @Composable ColumnScope.() -> Unit) {
    Glass(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp), dim = .10f, tint = Color.White.copy(alpha = .07f)) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun ActionPill(
    text: String, accent: Color, primary: Boolean,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier.clip(shape)
            .background(if (primary) accent.copy(alpha = .85f) else Color.White.copy(alpha = .09f))
            .border(1.dp, if (primary) Color.Transparent else Color.White.copy(alpha = .14f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) NovaBackground else Color.White, fontSize = 14.sp,
            fontWeight = if (primary) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
    }
}

@Composable
private fun Toggle(title: String, subtitle: String, checked: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(subtitle, color = WhiteMuted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = accent,
                uncheckedThumbColor = Color.White.copy(alpha = .8f),
                uncheckedTrackColor = Color.White.copy(alpha = .14f),
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

// Диалог в отдельном окне, поэтому здесь не «стекло», а плотная тёмная панель.
@Composable
internal fun DockSlotDialog(
    slot: Int, apps: List<InstalledApp>, accent: Color,
    onSelect: (String) -> Unit, onRemove: () -> Unit, onDismiss: () -> Unit
) {
    var query by remember(slot) { mutableStateOf("") }
    val matches = remember(query, apps) {
        apps.filter { it.label.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Dock · ячейка ${slot + 1}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Normal)
                Text("Выбери приложение для этого места", color = WhiteMuted, fontSize = 12.sp)
            }
        },
        text = {
            Column {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Поиск") },
                    shape = RoundedCornerShape(50),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = accent.copy(alpha = .7f),
                        unfocusedBorderColor = Color.White.copy(alpha = .14f),
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        cursorColor = accent
                    )
                )
                Spacer(Modifier.height(10.dp))
                if (matches.isEmpty()) {
                    Box(Modifier.fillMaxWidth().height(85.dp), contentAlignment = Alignment.Center) {
                        Text("Ничего не найдено", color = WhiteMuted, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 340.dp)) {
                        items(matches, key = { it.packageName }) { app ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                    .clickable { onSelect(app.packageName) }
                                    .padding(horizontal = 8.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIcon(app, 40)
                                Spacer(Modifier.width(14.dp))
                                Text(app.label, color = Color.White, fontSize = 15.sp, maxLines = 1,
                                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Готово", color = accent) } },
        dismissButton = { TextButton(onClick = onRemove) { Text("Очистить ячейку", color = Rose) } },
        containerColor = Color(0xFF161925),
        shape = RoundedCornerShape(30.dp)
    )
}
