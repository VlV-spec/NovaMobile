package com.novahome.mobile

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import kotlin.coroutines.resume
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Погода (Open-Meteo, без ключей; координаты округляются до ~1 км)
// ---------------------------------------------------------------------------

private data class CurrentWeather(val temperature: Int, val code: Int)

/** Кэш на весь процесс: возврат на главный экран не вызывает лишний запрос. */
private object WeatherCache {
    var value: CurrentWeather? = null
    var fetchedAt = 0L
}

private const val WEATHER_INTERVAL = 20 * 60 * 1000L

private suspend fun weatherForUser(context: Context): CurrentWeather? = withContext(Dispatchers.IO) {
    try {
        if (context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return@withContext null
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val last = runCatching { locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) }.getOrNull()
        val location: Location? = last ?: withTimeoutOrNull(8000L) {
            suspendCancellableCoroutine { continuation ->
                try {
                    locationManager.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, context.mainExecutor) { found ->
                        if (continuation.isActive) continuation.resume(found)
                    }
                } catch (_: Exception) {
                    if (continuation.isActive) continuation.resume(null)
                }
            }
        }
        if (location == null) return@withContext null
        val latitude = (location.latitude * 100).roundToInt() / 100.0
        val longitude = (location.longitude * 100).roundToInt() / 100.0
        val connection = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$latitude&longitude=$longitude" +
                "&current=temperature_2m,weather_code&forecast_days=1"
        ).openConnection() as HttpURLConnection
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        try {
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() }).getJSONObject("current")
            CurrentWeather(json.getDouble("temperature_2m").roundToInt(), json.getInt("weather_code"))
        } finally {
            connection.disconnect()
        }
    } catch (_: Exception) {
        null
    }
}

private fun weatherIcon(code: Int): String = when (code) {
    0 -> "☀"
    1, 2 -> "🌤"
    3 -> "☁"
    45, 48 -> "🌫"
    51, 53, 55, 56, 57 -> "🌦"
    61, 63, 65, 66, 67, 80, 81, 82 -> "🌧"
    71, 73, 75, 77, 85, 86 -> "❄"
    95, 96, 99 -> "⛈"
    else -> "🌡"
}

internal fun weatherWord(code: Int): String = when (code) {
    0 -> "Ясно"
    1, 2 -> "Малооблачно"
    3 -> "Пасмурно"
    45, 48 -> "Туман"
    51, 53, 55, 56, 57 -> "Морось"
    61, 63, 65, 66, 67, 80, 81, 82 -> "Дождь"
    71, 73, 75, 77, 85, 86 -> "Снег"
    95, 96, 99 -> "Гроза"
    else -> "Погода"
}

private fun formatTemperature(t: Int) = if (t > 0) "+$t°" else if (t < 0) "−${-t}°" else "0°"

// Samsung Weather часто скрыт из списка приложений: сначала он, потом
// системная категория «погода», в крайнем случае — поиск в браузере.
private fun openSamsungWeather(context: Context) {
    val samsungPackage = "com.sec.android.daemonapp"
    val weatherCategory = "android.intent.category.APP_WEATHER"
    val candidates = listOfNotNull(
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, weatherCategory).setPackage(samsungPackage),
        context.packageManager.getLaunchIntentForPackage(samsungPackage),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, weatherCategory)
    )
    for (intent in candidates) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (runCatching { context.startActivity(intent) }.isSuccess) return
    }
    runCatching {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=погода"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

// ---------------------------------------------------------------------------
// VPN: подключён ли и задержка до 1.1.1.1 (время TCP-соединения)
// ---------------------------------------------------------------------------

private data class VpnState(val connected: Boolean, val delayMs: Long?)

private suspend fun tcpDelay(): Long? = withContext(Dispatchers.IO) {
    try {
        val start = SystemClock.elapsedRealtime()
        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1800) }
        SystemClock.elapsedRealtime() - start
    } catch (_: Exception) {
        null
    }
}

private fun vpnActive(cm: ConnectivityManager): Boolean = runCatching {
    @Suppress("DEPRECATION")
    cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
}.getOrDefault(false)

// ---------------------------------------------------------------------------
// Строка стеклянных «пилюль» под часами: погода · батарея · VPN
// ---------------------------------------------------------------------------

@Composable
internal fun StatusChips(accent: Color, showBattery: Boolean, now: Long) {
    val context = LocalContext.current
    val visible = LocalLauncherVisible.current

    // --- погода ---
    var permitted by remember {
        mutableStateOf(context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    var refresh by remember { mutableIntStateOf(0) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permitted = granted
        if (granted) refresh++
    }
    val weather by produceState(initialValue = WeatherCache.value, permitted, refresh, visible) {
        if (!permitted || !visible) return@produceState
        while (true) {
            val age = SystemClock.elapsedRealtime() - WeatherCache.fetchedAt
            if (WeatherCache.value == null || age >= WEATHER_INTERVAL) {
                val fresh = weatherForUser(context)
                if (fresh != null) {
                    WeatherCache.value = fresh
                    WeatherCache.fetchedAt = SystemClock.elapsedRealtime()
                } else {
                    // Нет сети или геопозиции — повторим через 5 минут.
                    WeatherCache.fetchedAt = SystemClock.elapsedRealtime() - WEATHER_INTERVAL + 5 * 60 * 1000L
                }
            }
            value = WeatherCache.value
            val wait = WEATHER_INTERVAL - (SystemClock.elapsedRealtime() - WeatherCache.fetchedAt)
            delay(wait.coerceIn(60_000L, WEATHER_INTERVAL))
        }
    }

    // --- VPN ---
    val vpn by produceState(initialValue = VpnState(false, null), visible) {
        if (!visible) return@produceState
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var lastPingAt = 0L
        var ping: Long? = null
        while (true) {
            val active = vpnActive(cm)
            val t = SystemClock.elapsedRealtime()
            if (!active) ping = null
            else if (ping == null || t - lastPingAt > 30_000L) {
                ping = tcpDelay()
                lastPingAt = t
            }
            value = VpnState(active, ping)
            delay(5_000L)
        }
    }

    // --- батарея (обновляется вместе с часами) ---
    val battery = remember(now) {
        val info = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = info?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = info?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = info?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        if (level >= 0 && scale > 0) (level * 100 / scale) to charging else null
    }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val w = weather
        Chip(
            modifier = Modifier.weight(1f, fill = false),
            onClick = {
                if (!permitted) permission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                else openSamsungWeather(context)
            }
        ) {
            Text(
                when {
                    !permitted -> "📍 Погода"
                    w == null -> "🌡 —"
                    else -> "${weatherIcon(w.code)}  ${formatTemperature(w.temperature)}  ${weatherWord(w.code)}"
                },
                color = WhiteSoft, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (showBattery && battery != null) {
            val (percent, charging) = battery
            Chip(onClick = {
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }) {
                BatteryGlyph(percent, charging, accent)
                Spacer(Modifier.width(6.dp))
                Text("$percent%", color = WhiteSoft, fontSize = 13.sp, maxLines = 1)
            }
        }
        Chip(onClick = {
            runCatching { context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }) {
            Box(
                Modifier.size(7.dp).clip(CircleShape)
                    .background(if (vpn.connected) accent else Color.White.copy(alpha = .30f))
            )
            Spacer(Modifier.width(6.dp))
            Text(
                when {
                    !vpn.connected -> "VPN"
                    vpn.delayMs != null -> "VPN ${vpn.delayMs} мс"
                    else -> "VPN"
                },
                color = if (vpn.connected) WhiteSoft else WhiteMuted,
                fontSize = 13.sp, fontWeight = if (vpn.connected) FontWeight.Medium else FontWeight.Normal,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun Chip(modifier: Modifier = Modifier, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(50)
    Glass(modifier.clip(shape).clickable(onClick = onClick), shape = shape, dim = .18f) {
        Row(
            Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

/** Маленькая батарейка с заливкой по уровню заряда. */
@Composable
private fun BatteryGlyph(percent: Int, charging: Boolean, accent: Color) {
    val fill = when {
        charging -> accent
        percent <= 15 -> Color(0xFFFF6B6B)
        else -> Color.White.copy(alpha = .9f)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.width(20.dp).height(11.dp).clip(RoundedCornerShape(3.dp))
                .background(Color.White.copy(alpha = .22f))
                .padding(1.5.dp)
        ) {
            Box(
                Modifier.fillMaxHeight().fillMaxWidth((percent / 100f).coerceIn(.06f, 1f))
                    .clip(RoundedCornerShape(2.dp)).background(fill)
            )
        }
        Box(
            Modifier.padding(start = 1.dp).width(2.dp).height(5.dp)
                .clip(RoundedCornerShape(1.dp)).background(Color.White.copy(alpha = .35f))
        )
    }
}
