package com.novahome.mobile

/** Stable, testable Dock model, independent of Favorites and UI gestures. */
internal object DockLogic {
    const val SLOT_COUNT = 4
    private const val EMPTY = "~"

    fun normalize(raw: List<String>, installed: Set<String>): List<String> {
        val seen = mutableSetOf<String>()
        return (raw + List(SLOT_COUNT) { "" }).take(SLOT_COUNT).map { token ->
            val item = if (token == EMPTY) "" else token
            if (item.isNotBlank() && item in installed && seen.add(item)) item else ""
        }
    }

    fun restore(saved: String?, legacy: String?, favorites: List<String>, installed: Set<String>): List<String> {
        val raw = when {
            saved != null -> saved.split('|')
            legacy != null -> legacy.split('|')
            else -> favorites
        }
        return normalize(raw, installed)
    }

    fun encode(slots: List<String>): String {
        require(slots.size == SLOT_COUNT)
        return slots.joinToString("|") { it.ifEmpty { EMPTY } }
    }

    fun replace(slots: List<String>, slot: Int, pkg: String): List<String> {
        require(slots.size == SLOT_COUNT && slot in 0 until SLOT_COUNT && pkg.isNotBlank())
        val copy = slots.toMutableList()
        val previous = copy[slot]
        val other = copy.indexOf(pkg)
        if (other == slot) return copy
        if (other >= 0) copy[other] = previous
        copy[slot] = pkg
        return copy
    }

    fun remove(slots: List<String>, slot: Int): List<String> {
        require(slots.size == SLOT_COUNT && slot in 0 until SLOT_COUNT)
        return slots.toMutableList().apply { this[slot] = "" }
    }

    fun toggle(slots: List<String>, pkg: String): List<String> {
        require(slots.size == SLOT_COUNT && pkg.isNotBlank())
        val existing = slots.indexOf(pkg)
        if (existing >= 0) return remove(slots, existing)
        val available = slots.indexOf("")
        return replace(slots, if (available >= 0) available else SLOT_COUNT - 1, pkg)
    }
}
