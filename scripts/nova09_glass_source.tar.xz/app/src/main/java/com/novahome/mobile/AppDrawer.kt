package com.novahome.mobile

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
internal fun AppDrawer(
    apps: List<InstalledApp>,
    loading: Boolean,
    favorites: List<String>,
    accent: Color,
    columns: Int,
    editing: Boolean,
    onEdit: () -> Unit,
    onBack: () -> Unit,
    onLaunch: (InstalledApp) -> Unit,
    onFavorite: (String) -> Unit,
    dockPackages: Set<String>,
    onDock: (String) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var onlyFavorites by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val closeDrawer by rememberUpdatedState(onBack)
    val favoriteSet = favorites.toSet()
    val visibleApps = remember(search, apps, onlyFavorites, favoriteSet) {
        apps.filter {
            (search.isBlank() || it.label.contains(search.trim(), ignoreCase = true)) &&
                (!onlyFavorites || it.packageName in favoriteSet)
        }
    }

    Glass(
        Modifier.fillMaxSize(),
        shape = RectangleShape,
        dim = .42f,
        tint = Color.White.copy(alpha = .04f),
        outline = false
    ) {
        Column(
            Modifier.fillMaxSize()
                .safeDrawingPadding()
                .padding(horizontal = 18.dp)
                .padding(top = 8.dp)
        ) {
            // Заголовок: свайп вниз по нему закрывает меню.
            Row(
                Modifier.fillMaxWidth()
                    .pointerInput(Unit) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (total > 60f) closeDrawer() },
                            onVerticalDrag = { change, amount -> total += amount; change.consume() }
                        )
                    }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Приложения", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Light)
                    Text(
                        if (loading) "Загрузка…" else "${apps.size} установлено",
                        color = WhiteMuted, fontSize = 12.sp
                    )
                }
                Glass(
                    Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onEdit),
                    shape = RoundedCornerShape(50),
                    tint = if (editing) accent.copy(alpha = .35f) else Color.White.copy(alpha = .08f)
                ) {
                    Text(
                        if (editing) "Готово" else "Изменить",
                        color = Color.White, fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }

            // Поиск
            Glass(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                shape = RoundedCornerShape(50),
                tint = Color.White.copy(alpha = .10f)
            ) {
                Row(
                    Modifier.padding(horizontal = 18.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⌕", color = WhiteMuted, fontSize = 20.sp)
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f)) {
                        if (search.isEmpty()) Text("Найти приложение", color = WhiteMuted, fontSize = 16.sp)
                        BasicTextField(
                            value = search,
                            onValueChange = { search = it },
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                            cursorBrush = SolidColor(accent),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (search.isNotEmpty()) {
                        Text(
                            "✕", color = WhiteMuted, fontSize = 16.sp,
                            modifier = Modifier.clip(CircleShape).clickable { search = ""; focus.clearFocus() }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Row(
                Modifier.padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterPill("Все", selected = !onlyFavorites, accent = accent) { onlyFavorites = false }
                FilterPill("★ На экране", selected = onlyFavorites, accent = accent) { onlyFavorites = true }
                Spacer(Modifier.weight(1f))
                Text("${visibleApps.size}", fontSize = 12.sp, color = WhiteMuted)
            }

            if (editing) {
                Text(
                    "Коснись иконки — добавить на экран или убрать. «+ Dock» закрепляет в свободной ячейке Dock.",
                    color = WhiteMuted, fontSize = 12.sp, lineHeight = 17.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }

            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = accent)
                }
                visibleApps.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Ничего не найдено", color = WhiteMuted, fontSize = 14.sp)
                }
                else -> LazyVerticalGrid(
                    columns = GridCells.Fixed(columns),
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
                ) {
                    items(visibleApps, key = { it.packageName }) { app ->
                        DrawerIcon(
                            app = app, accent = accent, editing = editing,
                            favorite = app.packageName in favoriteSet,
                            dockPinned = app.packageName in dockPackages,
                            onClick = { if (editing) onFavorite(app.packageName) else onLaunch(app) },
                            onDock = { onDock(app.packageName) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterPill(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) accent.copy(alpha = .28f) else Color.White.copy(alpha = .07f))
            .border(1.dp, if (selected) accent.copy(alpha = .6f) else Color.White.copy(alpha = .12f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 9.dp)
    ) {
        Text(label, color = if (selected) Color.White else WhiteMuted, fontSize = 13.sp)
    }
}

@Composable
private fun DrawerIcon(
    app: InstalledApp,
    accent: Color,
    editing: Boolean,
    favorite: Boolean,
    dockPinned: Boolean,
    onClick: () -> Unit,
    onDock: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        PressScale(onClick = onClick) {
            Box(contentAlignment = Alignment.TopEnd) {
                AppIcon(app, 54, Modifier.padding(4.dp))
                if (editing) {
                    Box(
                        Modifier.size(20.dp).clip(CircleShape)
                            .background(if (favorite) accent else Color(0xFF4A4D5E))
                            .border(1.5.dp, NovaBackground, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (favorite) "✓" else "+", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Text(
            app.label, color = WhiteSoft, fontSize = 12.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp, start = 2.dp, end = 2.dp)
        )
        if (editing) {
            Text(
                if (dockPinned) "✓ Dock" else "+ Dock",
                color = if (dockPinned) accent else Color.White,
                fontSize = 10.sp, maxLines = 1,
                modifier = Modifier.padding(top = 5.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (dockPinned) accent.copy(alpha = .22f) else Color.White.copy(alpha = .10f))
                    .clickable(onClick = onDock)
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Иконки: рендер в фоне, LRU-кэш, размер под плотность экрана
// ---------------------------------------------------------------------------

internal object AppIconCache {
    // ~24 МБ: с запасом на 200+ иконок при размере под экран S24 Ultra.
    private val images = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = ((value.byteCount.toLong() + 1023L) / 1024L).toInt()
    }
    private val parallelism = Semaphore(4)

    fun peek(key: String): Bitmap? = synchronized(images) { images.get(key) }

    /** После обновления приложения его иконка могла поменяться. */
    fun evictPackage(packageName: String) = synchronized(images) {
        images.snapshot().keys.filter { it.startsWith("$packageName/") }.forEach { images.remove(it) }
    }

    suspend fun load(pm: PackageManager, app: InstalledApp, key: String, pixels: Int): Bitmap? {
        peek(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            parallelism.withPermit {
                peek(key) ?: runCatching {
                    drawableAsBitmap(pm.getActivityIcon(ComponentName(app.packageName, app.activityName)), pixels)
                }.getOrNull()?.also { result -> synchronized(images) { images.put(key, result) } }
            }
        }
    }
}

private fun drawableAsBitmap(drawable: Drawable, target: Int): Bitmap {
    val bitmap = Bitmap.createBitmap(target, target, Bitmap.Config.ARGB_8888)
    val icon = drawable.constantState?.newDrawable()?.mutate() ?: drawable.mutate()
    icon.setBounds(0, 0, target, target)
    icon.draw(Canvas(bitmap))
    return bitmap
}

@Composable
internal fun AppIcon(app: InstalledApp, size: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    // Рендерим с запасом под самый крупный размер иконки, но не больше 256 px.
    val pixels = remember(context) { (64 * context.resources.displayMetrics.density).roundToInt().coerceIn(96, 256) }
    val key = remember(app.packageName, app.activityName) { "${app.packageName}/${app.activityName}" }
    val bitmap by produceState(initialValue = AppIconCache.peek(key), key) {
        if (value == null) value = AppIconCache.load(context.packageManager, app, key, pixels)
    }
    val image = remember(bitmap) { bitmap?.asImageBitmap() }
    Box(modifier.size(size.dp), contentAlignment = Alignment.Center) {
        if (image != null) {
            Image(bitmap = image, contentDescription = app.label, modifier = Modifier.fillMaxSize())
        } else {
            Box(
                Modifier.fillMaxSize().clip(RoundedCornerShape(30)).background(Color.White.copy(alpha = .14f)),
                contentAlignment = Alignment.Center
            ) { Text(app.label.take(1).uppercase(), color = Color.White, fontSize = (size * .4f).sp) }
        }
    }
}
