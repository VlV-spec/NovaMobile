package com.novahome.mobile

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun HomeScreen(
    accent: Color,
    dock: List<InstalledApp?>,
    shortcuts: List<InstalledApp>,
    columns: Int,
    showClock: Boolean,
    compactClock: Boolean,
    showBatteryWidget: Boolean,
    showDate: Boolean,
    homeSignal: Int,
    onReorder: (String, String) -> Unit,
    onSettings: () -> Unit,
    onAppDrawer: () -> Unit,
    onLaunch: (InstalledApp) -> Unit,
    onEditFavorites: () -> Unit,
    onDockSlot: (Int) -> Unit,
    onDockRemove: (Int) -> Unit,
    onOpenAlarms: () -> Unit,
    onOpenCalendar: () -> Unit
) {
    val visible = LocalLauncherVisible.current
    val haptics = LocalHapticFeedback.current

    // --- часы: обновление ровно на границе минуты, только пока лаунчер виден ---
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - now % 60_000L + 20L)
        }
    }
    val locale = remember { Locale.forLanguageTag("ru") }
    val time = remember(now) { SimpleDateFormat("HH:mm", locale).format(Date(now)) }
    val date = remember(now) {
        SimpleDateFormat("EEEE, d MMMM", locale).format(Date(now)).replaceFirstChar { it.uppercase() }
    }

    // --- режим перестановки (логика из 0.8, без изменений по сути) ---
    var arranging by remember { mutableStateOf(false) }
    var selectedApp by remember { mutableStateOf<String?>(null) }
    var draggingApp by remember { mutableStateOf<String?>(null) }
    var fingerPosition by remember { mutableStateOf(Offset.Zero) }
    var dragDistance by remember { mutableStateOf(Offset.Zero) }
    val iconBounds = remember { mutableMapOf<String, Rect>() }
    val hoveredApp = draggingApp?.let { active ->
        iconBounds.entries.firstOrNull { (pkg, rect) -> pkg != active && rect.contains(fingerPosition) }?.key
    }

    fun stopDrag(allowDrop: Boolean) {
        val from = draggingApp
        val to = if (from != null) iconBounds.entries.firstOrNull { (pkg, rect) ->
            pkg != from && rect.contains(fingerPosition)
        }?.key else null
        if (allowDrop && from != null && to != null) {
            onReorder(from, to)
            selectedApp = null
        }
        draggingApp = null
        dragDistance = Offset.Zero
        fingerPosition = Offset.Zero
    }

    fun finishArranging() {
        stopDrag(false)
        arranging = false
        selectedApp = null
        iconBounds.clear()
    }

    // «Домой» и «Назад» выходят из режима перестановки.
    LaunchedEffect(homeSignal) { if (arranging) finishArranging() }
    BackHandler(enabled = arranging) { finishArranging() }

    fun iconDragModifier(pkg: String): Modifier {
        val dragGesture = if (arranging) {
            Modifier.pointerInput(pkg, arranging) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { localPosition ->
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        draggingApp = pkg
                        dragDistance = Offset.Zero
                        fingerPosition = (iconBounds[pkg]?.topLeft ?: Offset.Zero) + localPosition
                        selectedApp = null
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        dragDistance += amount
                        fingerPosition += amount
                    },
                    onDragEnd = { stopDrag(true) },
                    onDragCancel = { stopDrag(false) }
                )
            }
        } else Modifier
        return Modifier
            .onGloballyPositioned { iconBounds[pkg] = it.boundsInRoot() }
            .zIndex(if (draggingApp == pkg) 10f else 0f)
            .graphicsLayer {
                if (draggingApp == pkg) {
                    translationX = dragDistance.x
                    translationY = dragDistance.y
                    scaleX = 1.15f
                    scaleY = 1.15f
                    alpha = .9f
                }
            }
            .then(dragGesture)
    }

    fun selectForMove(packageName: String) {
        val previous = selectedApp
        when {
            previous == null -> selectedApp = packageName
            previous == packageName -> selectedApp = null
            else -> {
                onReorder(previous, packageName)
                selectedApp = null
            }
        }
    }

    // Свайп вверх по свободному месту открывает меню приложений.
    // rememberUpdatedState: жест не перезапускается при каждой перерисовке (тик часов).
    val openDrawer by rememberUpdatedState(onAppDrawer)
    val swipeUpToOpen = Modifier.pointerInput(Unit) {
        var total = 0f
        detectVerticalDragGestures(
            onDragStart = { total = 0f },
            onDragEnd = { if (total < -60f) openDrawer() },
            onVerticalDrag = { change, amount ->
                total += amount
                change.consume()
            }
        )
    }

    Column(
        Modifier.fillMaxSize()
            .safeDrawingPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 6.dp, bottom = 10.dp)
    ) {
        // --- верхние кнопки ---
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            RoundGlassButton(
                symbol = if (arranging) "✓" else "✎",
                highlighted = arranging, accent = accent,
                onClick = { if (arranging) finishArranging() else arranging = true }
            )
            Spacer(Modifier.width(10.dp))
            RoundGlassButton(symbol = "⚙", highlighted = false, accent = accent, onClick = onSettings)
        }

        // --- часы и дата ---
        if (showClock) {
            Text(
                time,
                color = Color.White,
                fontSize = if (compactClock) 64.sp else 96.sp,
                lineHeight = if (compactClock) 68.sp else 100.sp,
                fontWeight = FontWeight.Thin,
                letterSpacing = (-2).sp,
                style = TextOnWallpaper,
                modifier = Modifier
                    .padding(top = if (compactClock) 4.dp else 18.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onOpenAlarms)
                    .padding(horizontal = 4.dp)
            )
        }
        if (showDate) {
            Text(
                date,
                color = WhiteSoft, fontSize = 18.sp, fontWeight = FontWeight.Normal,
                style = TextOnWallpaper,
                modifier = Modifier
                    .padding(top = if (showClock) 0.dp else 18.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onOpenCalendar)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        StatusChips(accent = accent, showBattery = showBatteryWidget, now = now)

        // --- подсказка режима перестановки ---
        AnimatedVisibility(
            visible = arranging,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Glass(
                Modifier.fillMaxWidth().padding(top = 14.dp),
                shape = RoundedCornerShape(18.dp),
                tint = accent.copy(alpha = .16f)
            ) {
                Text(
                    when {
                        draggingApp != null -> if (hoveredApp != null) "Отпусти — значки поменяются местами"
                        else "Перетащи значок на другое приложение"
                        selectedApp == null -> "Зажми и перетащи значок, или коснись двух по очереди. Dock — кнопки под иконками."
                        else -> "Коснись другой иконки, чтобы поменять их местами"
                    },
                    color = Color.White, fontSize = 13.sp, lineHeight = 18.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }
        }

        // --- свободное место: здесь видны обои; свайп вверх — меню приложений ---
        Spacer(Modifier.weight(1f).fillMaxWidth().then(swipeUpToOpen))

        // --- избранное ---
        if (shortcuts.isEmpty()) {
            Text(
                "Добавить приложения на экран",
                color = WhiteSoft, fontSize = 14.sp, style = TextOnWallpaper,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onEditFavorites).padding(vertical = 18.dp)
            )
        } else {
            val rows = (shortcuts.size + columns - 1) / columns
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                modifier = Modifier.fillMaxWidth().heightIn(max = (rows.coerceAtMost(4) * 96).dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                userScrollEnabled = rows > 4
            ) {
                items(shortcuts, key = { it.packageName }) { app ->
                    HomeIcon(
                        app = app,
                        accent = accent,
                        selected = arranging && (selectedApp == app.packageName || hoveredApp == app.packageName),
                        modifier = iconDragModifier(app.packageName),
                        onClick = { if (arranging) selectForMove(app.packageName) else onLaunch(app) }
                    )
                }
            }
        }

        // --- ручка + Dock ---
        Box(
            Modifier.fillMaxWidth().height(22.dp).then(swipeUpToOpen),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.width(36.dp).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = .45f)))
        }
        Dock(
            dock = dock, accent = accent, arranging = arranging,
            onLaunch = onLaunch, onDockSlot = onDockSlot, onDockRemove = onDockRemove,
            onAppDrawer = onAppDrawer
        )
    }
}

@Composable
private fun Dock(
    dock: List<InstalledApp?>,
    accent: Color,
    arranging: Boolean,
    onLaunch: (InstalledApp) -> Unit,
    onDockSlot: (Int) -> Unit,
    onDockRemove: (Int) -> Unit,
    onAppDrawer: () -> Unit
) {
    Glass(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(34.dp),
        dim = .12f,
        tint = Color.White.copy(alpha = .10f)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Ровно четыре независимых места, включая пустые.
            dock.forEachIndexed { index, app ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    PressScale(
                        onClick = { if (arranging || app == null) onDockSlot(index) else onLaunch(app) }
                    ) {
                        if (app != null) {
                            AppIcon(app, 54)
                        } else {
                            Box(
                                Modifier.size(54.dp).clip(RoundedCornerShape(18.dp))
                                    .border(1.5.dp, Color.White.copy(alpha = .30f), RoundedCornerShape(18.dp)),
                                contentAlignment = Alignment.Center
                            ) { Text("+", color = Color.White.copy(alpha = .75f), fontSize = 24.sp) }
                        }
                    }
                    if (arranging) {
                        Text(
                            if (app == null) "Добавить" else "Заменить",
                            color = accent, fontSize = 10.sp, maxLines = 1,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp))
                                .clickable { onDockSlot(index) }.padding(top = 6.dp, bottom = 2.dp, start = 4.dp, end = 4.dp)
                        )
                        if (app != null) {
                            Text(
                                "Убрать", color = Rose, fontSize = 10.sp, maxLines = 1,
                                modifier = Modifier.clip(RoundedCornerShape(6.dp))
                                    .clickable { onDockRemove(index) }.padding(horizontal = 4.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PressScale(onClick = onAppDrawer) {
                    Box(
                        Modifier.size(54.dp).clip(RoundedCornerShape(18.dp))
                            .background(Color.White.copy(alpha = .16f))
                            .border(1.dp, Color.White.copy(alpha = .22f), RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) { AppsGlyph() }
                }
            }
        }
    }
}

/** Значок «все приложения»: сетка 3×3 из точек. */
@Composable
private fun AppsGlyph() {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(3) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(3) { Box(Modifier.size(5.dp).clip(CircleShape).background(Color.White)) }
            }
        }
    }
}

@Composable
private fun HomeIcon(
    app: InstalledApp,
    accent: Color,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        PressScale(onClick = onClick) {
            Box(
                if (selected) Modifier.border(2.dp, accent, RoundedCornerShape(20.dp)).padding(3.dp) else Modifier.padding(3.dp)
            ) { AppIcon(app, 56) }
        }
        Text(
            app.label,
            color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, style = TextOnWallpaper,
            modifier = Modifier.fillMaxWidth().padding(top = 3.dp, start = 2.dp, end = 2.dp)
        )
    }
}

/** Иконка чуть «вдавливается» при нажатии — вместо серой ряби. */
@Composable
internal fun PressScale(onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .88f else 1f, spring(dampingRatio = .55f, stiffness = 600f), label = "press")
    Box(
        Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
private fun RoundGlassButton(symbol: String, highlighted: Boolean, accent: Color, onClick: () -> Unit) {
    Glass(
        Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick),
        shape = CircleShape,
        tint = if (highlighted) accent.copy(alpha = .35f) else Color.White.copy(alpha = .08f)
    ) {
        Text(symbol, color = Color.White, fontSize = 18.sp, modifier = Modifier.align(Alignment.Center))
    }
}
