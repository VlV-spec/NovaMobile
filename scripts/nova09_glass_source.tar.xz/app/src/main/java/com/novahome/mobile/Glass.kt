package com.novahome.mobile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.max
import kotlin.math.roundToInt

/*
 * «Матовое стекло» без тяжёлых эффектов в реальном времени.
 *
 * Обои один раз уменьшаются и размываются в фоне. Каждая стеклянная панель
 * рисует под собой ровно тот кусок размытой картинки, который находится за ней
 * на экране, поэтому выглядит как настоящее стекло, но стоит одну drawImage.
 * Работает на любом Android 10+, не зависит от RenderEffect.
 */

@Immutable
internal class Backdrop(
    val sharp: ImageBitmap?,
    val blurred: ImageBitmap?,
    val rootSize: IntSize
)

internal val LocalBackdrop = compositionLocalOf { Backdrop(null, null, IntSize.Zero) }

/** Полноэкранные обои + затемнение. Рисуется самым нижним слоем. */
@Composable
internal fun WallpaperLayer(shade: Float) {
    val backdrop = LocalBackdrop.current
    Box(Modifier.fillMaxSize().background(NovaBackground)) {
        backdrop.sharp?.let {
            Image(
                bitmap = it, contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.High
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = (shade + .12f).coerceAtMost(.95f)),
                    .35f to Color.Black.copy(alpha = shade * .55f),
                    .7f to Color.Black.copy(alpha = shade * .45f),
                    1f to Color.Black.copy(alpha = (shade + .18f).coerceAtMost(.95f))
                )
            )
        )
    }
}

/**
 * Стеклянная поверхность: размытые обои под панелью, лёгкий цветной налёт,
 * тонкая светлая кромка сверху.
 */
@Composable
internal fun Glass(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    tint: Color = Color.White.copy(alpha = .08f),
    dim: Float = .22f,
    outline: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val backdrop = LocalBackdrop.current
    var origin by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier
            .onGloballyPositioned { origin = it.positionInRoot() }
            .clip(shape)
            .drawBehind {
                val image = backdrop.blurred
                if (image != null && backdrop.rootSize.width > 0) {
                    drawBackdropSlice(image, backdrop.rootSize, origin)
                } else {
                    drawRect(NovaPanel)
                }
                drawRect(Color.Black.copy(alpha = dim))
                drawRect(tint)
            }
            .then(
                if (outline) Modifier.border(
                    1.dp,
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = .26f), Color.White.copy(alpha = .05f))),
                    shape
                ) else Modifier
            ),
        content = content
    )
}

/** Тот же расчёт, что у ContentScale.Crop + Alignment.Center у основных обоев. */
private fun DrawScope.drawBackdropSlice(image: ImageBitmap, root: IntSize, origin: Offset) {
    val scale = max(root.width / image.width.toFloat(), root.height / image.height.toFloat())
    val offsetX = (root.width - image.width * scale) / 2f
    val offsetY = (root.height - image.height * scale) / 2f
    val left = ((origin.x - offsetX) / scale).roundToInt().coerceIn(0, image.width - 1)
    val top = ((origin.y - offsetY) / scale).roundToInt().coerceIn(0, image.height - 1)
    val width = (size.width / scale).roundToInt().coerceIn(1, image.width - left)
    val height = (size.height / scale).roundToInt().coerceIn(1, image.height - top)
    drawImage(
        image = image,
        srcOffset = IntOffset(left, top),
        srcSize = IntSize(width, height),
        dstOffset = IntOffset.Zero,
        dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
        filterQuality = FilterQuality.High
    )
}

// ---------------------------------------------------------------------------
// Загрузка обоев (вызывается на Dispatchers.IO)
// ---------------------------------------------------------------------------

/**
 * Фото из галереи: учитывает поворот из EXIF (ImageDecoder делает это сам),
 * ограничено 1440×3200 (экран S24 Ultra — 1440×3120), полноцветное ARGB_8888 —
 * без полос на градиентах неба и тёмных фонах.
 */
internal fun decodeWallpaper(context: Context, uri: Uri): Bitmap? = runCatching {
    val source = ImageDecoder.createSource(context.contentResolver, uri)
    ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        // Программная память нужна, чтобы потом прочитать пиксели для размытия.
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val scale = minOf(1f, 1440f / info.size.width, 3200f / info.size.height)
        if (scale < 1f) {
            decoder.setTargetSize(
                (info.size.width * scale).roundToInt().coerceAtLeast(1),
                (info.size.height * scale).roundToInt().coerceAtLeast(1)
            )
        }
    }
}.getOrNull()

/** Обои по умолчанию: мягкое «северное сияние» в цветах выбранной темы. */
internal fun auroraWallpaper(accent: Color, width: Int = 720, height: Int = 1560): Bitmap {
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(NovaBackground.toArgb())
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    fun glow(cx: Float, cy: Float, radius: Float, color: Color, alpha: Float) {
        paint.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(color.copy(alpha = alpha).toArgb(), color.copy(alpha = 0f).toArgb()),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, paint)
    }
    val w = width.toFloat()
    val h = height.toFloat()
    glow(w * .15f, h * .12f, w * .95f, accent, .55f)
    glow(w * .95f, h * .38f, w * .80f, Color(0xFF3A6BFF), .32f)
    glow(w * .25f, h * .72f, w * .90f, accent, .24f)
    glow(w * .85f, h * .95f, w * .75f, Color(0xFFFF5FA8), .20f)
    return bitmap
}

/** Уменьшение + трёхпроходное box-размытие ≈ гауссово. ~240 px шириной хватает. */
internal fun blurredCopy(source: Bitmap, targetWidth: Int = 240, radius: Int = 9): Bitmap {
    val w = targetWidth.coerceAtMost(source.width).coerceAtLeast(1)
    val h = (source.height * w / source.width.toFloat()).roundToInt().coerceAtLeast(1)
    val small = Bitmap.createScaledBitmap(source, w, h, true)
    val pixels = IntArray(w * h)
    small.getPixels(pixels, 0, w, 0, 0, w, h)
    if (small !== source) small.recycle()
    repeat(3) {
        boxBlurHorizontal(pixels, w, h, radius)
        boxBlurVertical(pixels, w, h, radius)
    }
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(pixels, 0, w, 0, 0, w, h)
    return out
}

private fun boxBlurHorizontal(p: IntArray, w: Int, h: Int, r: Int) {
    val line = IntArray(w)
    val div = 2 * r + 1
    for (y in 0 until h) {
        val row = y * w
        var a = 0; var red = 0; var g = 0; var b = 0
        for (i in -r..r) {
            val c = p[row + i.coerceIn(0, w - 1)]
            a += c ushr 24; red += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255
        }
        for (x in 0 until w) {
            line[x] = ((a / div) shl 24) or ((red / div) shl 16) or ((g / div) shl 8) or (b / div)
            val add = p[row + (x + r + 1).coerceAtMost(w - 1)]
            val rem = p[row + (x - r).coerceAtLeast(0)]
            a += (add ushr 24) - (rem ushr 24)
            red += ((add shr 16) and 255) - ((rem shr 16) and 255)
            g += ((add shr 8) and 255) - ((rem shr 8) and 255)
            b += (add and 255) - (rem and 255)
        }
        System.arraycopy(line, 0, p, row, w)
    }
}

private fun boxBlurVertical(p: IntArray, w: Int, h: Int, r: Int) {
    val column = IntArray(h)
    val div = 2 * r + 1
    for (x in 0 until w) {
        var a = 0; var red = 0; var g = 0; var b = 0
        for (i in -r..r) {
            val c = p[i.coerceIn(0, h - 1) * w + x]
            a += c ushr 24; red += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255
        }
        for (y in 0 until h) {
            column[y] = ((a / div) shl 24) or ((red / div) shl 16) or ((g / div) shl 8) or (b / div)
            val add = p[(y + r + 1).coerceAtMost(h - 1) * w + x]
            val rem = p[(y - r).coerceAtLeast(0) * w + x]
            a += (add ushr 24) - (rem ushr 24)
            red += ((add shr 16) and 255) - ((rem shr 16) and 255)
            g += ((add shr 8) and 255) - ((rem shr 8) and 255)
            b += (add and 255) - (rem and 255)
        }
        for (y in 0 until h) p[y * w + x] = column[y]
    }
}
