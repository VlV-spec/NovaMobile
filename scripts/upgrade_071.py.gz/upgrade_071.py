#!/usr/bin/env python3
"""Nova Mobile 0.7.1: tap clock for alarms and dates for calendar."""
from pathlib import Path

source = Path('app/src/main/java/com/novahome/mobile/MainActivity.kt')
s = source.read_text(encoding='utf-8')

def change(old: str, new: str) -> None:
    global s
    count = s.count(old)
    if count != 1:
        raise RuntimeError(f'Expected one matching anchor, found {count}: {old[:110]!r}')
    s = s.replace(old, new, 1)

change('import android.provider.Settings\n',
       'import android.provider.Settings\nimport android.provider.AlarmClock\nimport android.provider.CalendarContract\n')

change('        setContent {\n', '''        // Prefer Android's default alarm/calendar app. Fall back to an installed app.
        fun startFirstAvailable(intents: List<Intent>, preferredPackages: List<String>, label: String) {
            for (intent in intents) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (runCatching { startActivity(intent) }.isSuccess) return
            }
            val fallback = preferredPackages.firstNotNullOfOrNull { pkg ->
                apps.find { it.packageName == pkg }
            }
            if (fallback != null) launch(fallback)
            else Toast.makeText(this, "Не найдено приложение: $label", Toast.LENGTH_SHORT).show()
        }

        fun openAlarms() = startFirstAvailable(
            intents = listOf(Intent(AlarmClock.ACTION_SHOW_ALARMS)),
            preferredPackages = listOf(
                "com.sec.android.app.clockpackage", "com.google.android.deskclock", "com.android.deskclock"
            ),
            label = "Часы"
        )

        fun openCalendar() = startFirstAvailable(
            intents = listOf(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR),
                Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI)
            ),
            preferredPackages = listOf(
                "com.samsung.android.calendar", "com.google.android.calendar", "com.android.calendar"
            ),
            label = "Календарь"
        )

        setContent {
''')

change('                            onSystemSettings = { startActivity(Intent(Settings.ACTION_SETTINGS)) }\n',
       '                            onSystemSettings = { startActivity(Intent(Settings.ACTION_SETTINGS)) },\n'
       '                            onOpenAlarms = { openAlarms() },\n'
       '                            onOpenCalendar = { openCalendar() }\n')

change('    onSystemSettings: () -> Unit\n) {\n',
       '    onSystemSettings: () -> Unit,\n    onOpenAlarms: () -> Unit,\n    onOpenCalendar: () -> Unit\n) {\n')

change('''                Text(time, color = Color.White, fontWeight = FontWeight.Light,
                    fontSize = if (compactClock) 48.sp else 70.sp,
                    lineHeight = if (compactClock) 53.sp else 75.sp)
                Text(date.replaceFirstChar { it.uppercase() }, color = WhiteMuted, fontSize = 14.sp)
''', '''                Text(time, color = Color.White, fontWeight = FontWeight.Light,
                    fontSize = if (compactClock) 48.sp else 70.sp,
                    lineHeight = if (compactClock) 53.sp else 75.sp,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onOpenAlarms)
                        .padding(vertical = 3.dp))
                Text(date.replaceFirstChar { it.uppercase() }, color = WhiteMuted, fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(9.dp))
                        .clickable(onClick = onOpenCalendar)
                        .padding(vertical = 5.dp))
''')

change('''                    Row(
                        Modifier.weight(1f).height(78.dp).clip(RoundedCornerShape(20.dp))
                            .background(Panel.copy(alpha = .91f))
                            .border(1.dp, accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 13.dp, vertical = 9.dp),
''', '''                    Row(
                        Modifier.weight(1f).height(78.dp).clip(RoundedCornerShape(20.dp))
                            .background(Panel.copy(alpha = .91f))
                            .border(1.dp, accent.copy(alpha = .18f), RoundedCornerShape(20.dp))
                            .clickable(onClick = onOpenCalendar)
                            .padding(horizontal = 13.dp, vertical = 9.dp),
''')

change('Text("Nova Mobile 0.7 · Native Widgets Preview"',
       'Text("Nova Mobile 0.7.1 · Clock & Calendar Preview"')
source.write_text(s, encoding='utf-8')

build = Path('app/build.gradle.kts')
data = build.read_text(encoding='utf-8')
assert 'applicationId = "com.novahome.mobile.widgets07preview"' in data
assert 'versionCode = 11' in data
assert 'versionName = "0.7.0-preview"' in data
data = data.replace('applicationId = "com.novahome.mobile.widgets07preview"',
                    'applicationId = "com.novahome.mobile.clickwidgets071"')
data = data.replace('versionCode = 11', 'versionCode = 12')
data = data.replace('versionName = "0.7.0-preview"', 'versionName = "0.7.1-preview"')
build.write_text(data, encoding='utf-8')

manifest = Path('app/src/main/AndroidManifest.xml')
data = manifest.read_text(encoding='utf-8')
assert 'android:label="Nova Mobile 0.7"' in data
manifest.write_text(data.replace('android:label="Nova Mobile 0.7"',
                                 'android:label="Nova Mobile 0.7.1"'), encoding='utf-8')
print('Nova Mobile 0.7.1: interactive clock and calendar patch applied')
