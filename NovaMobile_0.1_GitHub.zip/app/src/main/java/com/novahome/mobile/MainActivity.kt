package com.novahome.mobile

import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Background = Color(0xFF080910)
private val Panel = Color(0xFF171927)
private val Purple = Color(0xFFBFA1FF)
private val Cyan = Color(0xFF75E2D6)

data class InstalledApp(val label: String, val packageName: String, val activityName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("nova", MODE_PRIVATE)
        val pm = packageManager
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .mapNotNull { info ->
                info.activityInfo?.let {
                    InstalledApp(info.loadLabel(pm).toString(), it.packageName, it.name)
                }
            }
            .distinctBy { it.packageName }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })

        // Only provide defaults when the user has never chosen favorites.
        if (!prefs.contains("favorites")) {
            val preferred = listOf(
                "com.google.android.youtube", "com.android.chrome", "com.sec.android.app.camera",
                "com.sec.android.gallery3d", "com.google.android.gm", "org.telegram.messenger",
                "com.google.android.apps.maps", "com.android.vending", "com.samsung.android.dialer"
            )
            val suggested = preferred.mapNotNull { pkg -> apps.find { it.packageName == pkg } }
                .plus(apps.filterNot { it.packageName in preferred }.take(8))
                .distinctBy { it.packageName }.take(9)
            prefs.edit().putString("favorites", suggested.joinToString("|") { it.packageName }).apply()
        }

        fun launch(app: InstalledApp) {
            val exact = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(app.packageName, app.activityName))
            val result = runCatching { startActivity(exact) }
            if (result.isFailure) {
                val fallback = runCatching {
                    pm.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
                }
                if (fallback.isFailure) Toast.makeText(this, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
            }
        }

        setContent {
            var drawerOpen by remember { mutableStateOf(false) }
            var settingsOpen by remember { mutableStateOf(false) }
            var editing by remember { mutableStateOf(false) }
            var search by remember { mutableStateOf("") }
            var columns by remember { mutableIntStateOf(prefs.getInt("columns", 4).coerceIn(3, 5)) }
            var purple by remember { mutableStateOf(prefs.getBoolean("purple", true)) }
            val accent = if (purple) Purple else Cyan
            val favorites = remember {
                mutableStateListOf<String>().apply {
                    addAll(prefs.getString("favorites", "").orEmpty().split("|").filter { it.isNotBlank() })
                }
            }
            fun toggleFavorite(pkg: String) {
                if (pkg in favorites) favorites.remove(pkg) else favorites.add(pkg)
                prefs.edit().putString("favorites", favorites.joinToString("|")).apply()
            }
            fun openApps() { drawerOpen = true; settingsOpen = false; search = "" }
            val homeApps = favorites.mapNotNull { pkg -> apps.find { it.packageName == pkg } }
            val dock = homeApps.take(4)
            val shortcutApps = homeApps.drop(4).take(12)
            MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = Background, surface = Panel)) {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF111127), Background, Background))
                    )
                ) {
                    when {
                        settingsOpen -> NovaSettings(
                            columns, purple, accent,
                            onColumns = { columns = it; prefs.edit().putInt("columns", it).apply() },
                            onPurple = { purple = it; prefs.edit().putBoolean("purple", it).apply() },
                            onBack = { settingsOpen = false },
                            onEditFavorites = { settingsOpen = false; editing = true; openApps() }
                        )
                        drawerOpen -> AppDrawer(
                            apps = apps, favorites = favorites, accent = accent, columns = columns,
                            editing = editing, search = search,
                            onSearch = { search = it },
                            onEdit = { editing = !editing },
                            onBack = { drawerOpen = false; editing = false },
                            onLaunch = { launch(it) }, onFavorite = { toggleFavorite(it) }
                        )
                        else -> HomeScreen(
                            accent = accent, dock = dock, shortcuts = shortcutApps, columns = columns,
                            onSettings = { settingsOpen = true }, onAppDrawer = { openApps() },
                            onLaunch = { launch(it) },
                            onEditFavorites = { editing = true; openApps() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    accent: Color,
    dock: List<InstalledApp>,
    shortcuts: List<InstalledApp>,
    columns: Int,
    onSettings: () -> Unit,
    onAppDrawer: () -> Unit,
    onLaunch: (InstalledApp) -> Unit,
    onEditFavorites: () -> Unit
) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { now = System.currentTimeMillis(); delay(20_000L) }
    }
    val time = remember(now) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now)) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 14.dp, bottom = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Text("NOVA", fontSize = 23.sp, fontWeight = FontWeight.Black, color = accent)
                Spacer(Modifier.width(8.dp))
                Text("HOME", color = Color.White.copy(alpha = .4f), fontSize = 10.sp, letterSpacing = 2.sp)
            }
            TextButton(onClick = onSettings) { Text("⚙", color = accent, fontSize = 26.sp) }
        }
        Spacer(Modifier.height(35.dp))
        Text(date.replaceFirstChar { it.uppercase() }, color = Color.White.copy(alpha = .65f), fontSize = 15.sp)
        Text(time, color = Color.White, fontWeight = FontWeight.Light, fontSize = 76.sp, lineHeight = 82.sp)
        Text("Твой экран. Твои правила.", color = Color.White.copy(alpha = .40f), fontSize = 13.sp)
        Spacer(Modifier.height(34.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("ИЗБРАННОЕ", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = onEditFavorites) { Text("Изменить", color = Color.White.copy(alpha = .7f), fontSize = 12.sp) }
        }
        Spacer(Modifier.height(8.dp))
        if (shortcuts.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Text("Добавь приложения в избранное", color = Color.White.copy(alpha = .5f), fontSize = 13.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(shortcuts, key = { it.packageName }) { app ->
                    AppShortcut(app, accent, false, false, { onLaunch(app) }, {})
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(27.dp))
                .background(Panel.copy(alpha = .97f))
                .border(1.dp, Color.White.copy(alpha = .09f), RoundedCornerShape(27.dp))
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            dock.forEach { app ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    AppIcon(app, 49, Modifier.clickable { onLaunch(app) })
                }
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(49.dp).clip(RoundedCornerShape(16.dp))
                        .background(accent.copy(alpha = .16f)).clickable { onAppDrawer() },
                    contentAlignment = Alignment.Center
                ) { Text("▦", color = accent, fontSize = 29.sp) }
            }
        }
    }
}

@Composable
private fun AppDrawer(
    apps: List<InstalledApp>,
    favorites: List<String>,
    accent: Color,
    columns: Int,
    editing: Boolean,
    search: String,
    onSearch: (String) -> Unit,
    onEdit: () -> Unit,
    onBack: () -> Unit,
    onLaunch: (InstalledApp) -> Unit,
    onFavorite: (String) -> Unit
) {
    val visible = remember(search, apps) { apps.filter { it.label.contains(search, ignoreCase = true) } }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = onBack) { Text("←", color = accent, fontSize = 26.sp) }
            Text("Приложения", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            TextButton(onClick = onEdit) { Text(if (editing) "Готово" else "Избранное", fontSize = 12.sp, color = accent) }
        }
        OutlinedTextField(
            value = search, onValueChange = onSearch, singleLine = true,
            placeholder = { Text("Поиск приложений", color = Color.White.copy(alpha = .45f)) },
            leadingIcon = { Text("⌕", color = accent, fontSize = 27.sp) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            shape = RoundedCornerShape(19.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = accent.copy(alpha = .7f),
                unfocusedBorderColor = Color.White.copy(alpha = .12f),
                focusedContainerColor = Panel, unfocusedContainerColor = Panel
            )
        )
        if (editing) Text("Нажимай на значки, чтобы добавить или убрать из избранного", color = Color.White.copy(alpha = .55f), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns), modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(visible, key = { it.packageName }) { app ->
                AppShortcut(
                    app = app, accent = accent, editing = editing,
                    favorite = app.packageName in favorites,
                    onLaunch = { onLaunch(app) }, onToggle = { onFavorite(app.packageName) }
                )
            }
        }
    }
}

@Composable
private fun NovaSettings(
    columns: Int, purple: Boolean, accent: Color,
    onColumns: (Int) -> Unit, onPurple: (Boolean) -> Unit,
    onBack: () -> Unit, onEditFavorites: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 27.sp, color = accent) }
            Text("Nova · Настройки", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(28.dp))
        Text("Сетка приложений", color = Color.White, fontSize = 17.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(3, 4, 5).forEach { value ->
                OutlinedButton(onClick = { onColumns(value) }, shape = RoundedCornerShape(15.dp)) {
                    Text("$value", color = if (columns == value) accent else Color.White.copy(alpha = .55f))
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Фиолетовый акцент", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = purple, onCheckedChange = onPurple)
        }
        Spacer(Modifier.height(22.dp))
        Button(onClick = onEditFavorites, modifier = Modifier.fillMaxWidth()) { Text("Настроить избранное") }
        Spacer(Modifier.height(18.dp))
        Text("Nova Mobile 0.2 · Предварительная версия", color = Color.White.copy(alpha = .45f), fontSize = 12.sp)
        Text("One UI Home остаётся установленным. Настоящие системные виджеты и перетаскивание плиток пока не добавлены.", color = Color.White.copy(alpha = .45f), fontSize = 12.sp)
    }
}

@Composable
private fun AppShortcut(
    app: InstalledApp,
    accent: Color,
    editing: Boolean,
    favorite: Boolean,
    onLaunch: () -> Unit,
    onToggle: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().height(94.dp).clip(RoundedCornerShape(15.dp))
            .clickable { if (editing) onToggle() else onLaunch() }
            .padding(top = 7.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            AppIcon(app, 53)
            if (editing) {
                Box(
                    Modifier.size(19.dp).clip(RoundedCornerShape(9.dp))
                        .background(if (favorite) accent else Color(0xFF46485A)),
                    contentAlignment = Alignment.Center
                ) { Text(if (favorite) "✓" else "+", fontSize = 12.sp, color = Background) }
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            app.label, color = Color.White.copy(alpha = .91f), fontSize = 11.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 1.dp)
        )
    }
}

@Composable
private fun AppIcon(app: InstalledApp, size: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap = remember(app.packageName, app.activityName) {
        runCatching {
            val pm = context.packageManager
            val drawable = pm.getActivityIcon(ComponentName(app.packageName, app.activityName))
            drawableAsBitmap(drawable).asImageBitmap()
        }.getOrNull()
    }
    Box(modifier.size(size.dp), contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(bitmap = bitmap, contentDescription = app.label, modifier = Modifier.fillMaxSize())
        } else {
            Box(
                Modifier.fillMaxSize().clip(RoundedCornerShape(15.dp)).background(Panel),
                contentAlignment = Alignment.Center
            ) { Text(app.label.take(1).uppercase(), color = Purple, fontSize = 22.sp) }
        }
    }
}

private fun drawableAsBitmap(drawable: Drawable): Bitmap {
    val target = 144
    val bitmap = Bitmap.createBitmap(target, target, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val icon = drawable.constantState?.newDrawable()?.mutate() ?: drawable.mutate()
    icon.setBounds(0, 0, target, target)
    icon.draw(canvas)
    return bitmap
}
