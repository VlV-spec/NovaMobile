package com.novahome.mobile

import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.content.pm.PackageManager
import android.util.LruCache
import android.graphics.drawable.Drawable
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Background = Color(0xFF080910)
private val Panel = Color(0xFF171927)
private val Purple = Color(0xFFBFA1FF)
private val Cyan = Color(0xFF75E2D6)
private val Rose = Color(0xFFFFA4C8)
private val WhiteMuted = Color.White.copy(alpha = .62f)
private val themes = listOf(Purple, Cyan, Rose)
private val themeNames = listOf("Violet", "Arctic", "Rose")

data class InstalledApp(val label: String, val packageName: String, val activityName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("nova", MODE_PRIVATE)
        val pm = packageManager
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .mapNotNull { info ->
                info.activityInfo?.let {
                    InstalledApp(info.loadLabel(pm).toString(), it.packageName, it.name)
                }
            }
            .distinctBy { it.packageName }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })

        if (!prefs.contains("favorites")) {
            val preferred = listOf(
                "com.google.android.youtube", "com.android.chrome", "com.sec.android.app.camera",
                "com.sec.android.gallery3d", "com.google.android.gm", "org.telegram.messenger",
                "com.google.android.apps.maps", "com.android.vending", "com.samsung.android.dialer"
            )
            val suggested = preferred.mapNotNull { pkg -> apps.find { it.packageName == pkg } }
                .plus(apps.filterNot { it.packageName in preferred }.take(8))
                .distinctBy { it.packageName }.take(12)
            prefs.edit().putString("favorites", suggested.joinToString("|") { it.packageName }).apply()
        }

        fun launch(app: InstalledApp) {
            val exact = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(app.packageName, app.activityName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val ok = runCatching { startActivity(exact) }.isSuccess
            if (!ok) {
                val fallback = runCatching {
                    pm.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
                        ?: error("No launch intent")
                }
                if (fallback.isFailure) Toast.makeText(this, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
            }
        }

        setContent {
            var drawerOpen by remember { mutableStateOf(false) }
            var settingsOpen by remember { mutableStateOf(false) }
            var editing by remember { mutableStateOf(false) }
            var search by remember { mutableStateOf("") }
            var columns by remember { mutableIntStateOf(prefs.getInt("columns", 4).coerceIn(3, 5)) }
            val legacyTheme = if (prefs.getBoolean("purple", true)) 0 else 1
            var palette by remember { mutableIntStateOf(prefs.getInt("palette", legacyTheme).coerceIn(0, 2)) }
            val accent = themes[palette]
            val favorites = remember {
                mutableStateListOf<String>().apply {
                    addAll(prefs.getString("favorites", "").orEmpty().split("|").filter { it.isNotBlank() })
                }
            }
            fun toggleFavorite(pkg: String) {
                if (pkg in favorites) favorites.remove(pkg) else favorites.add(pkg)
                prefs.edit().putString("favorites", favorites.joinToString("|")).apply()
            }
            fun openApps(edit: Boolean = false) {
                drawerOpen = true
                settingsOpen = false
                editing = edit
                search = ""
            }
            val homeApps = favorites.mapNotNull { pkg -> apps.find { it.packageName == pkg } }
            val dock = homeApps.take(4)
            val shortcuts = homeApps.drop(4).take(12)
            BackHandler(enabled = drawerOpen || settingsOpen) {
                if (drawerOpen) { drawerOpen = false; editing = false }
                else settingsOpen = false
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = Background, surface = Panel)) {
                Box(
                    Modifier.fillMaxSize().background(Background)
                        .background(Brush.verticalGradient(listOf(accent.copy(alpha = .14f), Color(0xFF111321), Background, Background)))
                        .safeDrawingPadding()
                ) {
                    when {
                        settingsOpen -> NovaSettings(
                            columns = columns, palette = palette, accent = accent,
                            onColumns = { columns = it; prefs.edit().putInt("columns", it).apply() },
                            onPalette = { palette = it; prefs.edit().putInt("palette", it).apply() },
                            onBack = { settingsOpen = false },
                            onEditFavorites = { openApps(true) }
                        )
                        drawerOpen -> AppDrawer(
                            apps = apps, favorites = favorites, accent = accent, columns = columns,
                            editing = editing, search = search, onSearch = { search = it },
                            onEdit = { editing = !editing },
                            onBack = { drawerOpen = false; editing = false },
                            onLaunch = { launch(it) }, onFavorite = { toggleFavorite(it) }
                        )
                        else -> HomeScreen(
                            accent = accent, dock = dock, shortcuts = shortcuts, columns = columns,
                            onSettings = { settingsOpen = true }, onAppDrawer = { openApps() },
                            onLaunch = { launch(it) }, onEditFavorites = { openApps(true) },
                            onSystemSettings = { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    accent: Color,
    dock: List<InstalledApp>,
    shortcuts: List<InstalledApp>,
    columns: Int,
    onSettings: () -> Unit,
    onAppDrawer: () -> Unit,
    onLaunch: (InstalledApp) -> Unit,
    onEditFavorites: () -> Unit,
    onSystemSettings: () -> Unit
) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        while (true) { now = System.currentTimeMillis(); delay(30_000L) }
    }
    val time = remember(now) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date(now)) }
    val battery = remember(now) {
        val info = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = info?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = info?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) (level * 100 / scale).toString() + "%" else "—"
    }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp).padding(top = 12.dp, bottom = 9.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                Text("N", fontSize = 20.sp, fontWeight = FontWeight.Black, color = accent)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("NOVA", fontSize = 17.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 2.sp)
                Text("MOBILE · PREVIEW", color = accent.copy(alpha = .8f), fontSize = 9.sp, letterSpacing = 1.1.sp)
            }
            Box(Modifier.clip(RoundedCornerShape(13.dp)).background(Panel.copy(alpha = .88f)).padding(horizontal = 11.dp, vertical = 9.dp)) {
                Text("⚡ $battery", color = WhiteMuted, fontSize = 12.sp)
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(Panel.copy(alpha = .92f))
                .clickable(onClick = onSettings), contentAlignment = Alignment.Center) {
                Text("⚙", color = accent, fontSize = 22.sp)
            }
        }
        Spacer(Modifier.height(25.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(29.dp))
                .background(Brush.linearGradient(listOf(Panel.copy(alpha = .98f), accent.copy(alpha = .10f), Panel)))
                .border(1.dp, accent.copy(alpha = .22f), RoundedCornerShape(29.dp))
                .padding(horizontal = 22.dp, vertical = 19.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).clip(CircleShape).background(accent))
                Spacer(Modifier.width(7.dp))
                Text("ТВОЙ МОМЕНТ", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(time, color = Color.White, fontWeight = FontWeight.Light, fontSize = 70.sp, lineHeight = 75.sp)
            Text(date.replaceFirstChar { it.uppercase() }, color = WhiteMuted, fontSize = 14.sp)
            Spacer(Modifier.height(15.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = .09f)))
            Spacer(Modifier.height(12.dp))
            Text("Твой экран. Твои правила.", color = Color.White.copy(alpha = .51f), fontSize = 12.sp)
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
            QuickAction("▦", "Все приложения", accent, Modifier.weight(1f), onAppDrawer)
            QuickAction("⚙", "Система", accent, Modifier.weight(1f), onSystemSettings)
        }
        Spacer(Modifier.height(21.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("ИЗБРАННОЕ", color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.6.sp, modifier = Modifier.weight(1f))
            Text("${dock.size + shortcuts.size}", color = WhiteMuted, fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onEditFavorites) { Text("Изменить", color = WhiteMuted, fontSize = 12.sp) }
        }
        if (shortcuts.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                Text("Добавь любимые приложения", color = WhiteMuted, fontSize = 13.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(shortcuts, key = { it.packageName }) { app ->
                    AppShortcut(app, accent, false, false, { onLaunch(app) }, {})
                }
            }
        }
        Spacer(Modifier.height(9.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(27.dp))
                .background(Panel.copy(alpha = .97f))
                .border(1.dp, accent.copy(alpha = .18f), RoundedCornerShape(27.dp))
                .padding(horizontal = 9.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            dock.forEach { app ->
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    AppIcon(app, 47, Modifier.clickable { onLaunch(app) })
                }
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Box(Modifier.size(47.dp).clip(RoundedCornerShape(15.dp))
                    .background(accent.copy(alpha = .17f)).clickable { onAppDrawer() }, contentAlignment = Alignment.Center) {
                    Text("▦", color = accent, fontSize = 27.sp)
                }
            }
        }
    }
}

@Composable
private fun QuickAction(
    symbol: String, label: String, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit
) {
    Row(modifier.clip(RoundedCornerShape(17.dp))
        .background(Panel.copy(alpha = .8f))
        .border(1.dp, Color.White.copy(alpha = .07f), RoundedCornerShape(17.dp))
        .clickable(onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol, color = accent, fontSize = 21.sp)
        Spacer(Modifier.width(9.dp))
        Text(label, color = Color.White.copy(alpha = .87f), fontSize = 12.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun AppDrawer(
    apps: List<InstalledApp>,
    favorites: List<String>,
    accent: Color,
    columns: Int,
    editing: Boolean,
    search: String,
    onSearch: (String) -> Unit,
    onEdit: () -> Unit,
    onBack: () -> Unit,
    onLaunch: (InstalledApp) -> Unit,
    onFavorite: (String) -> Unit
) {
    var onlyFavorites by remember { mutableStateOf(false) }
    val favoriteSet = remember(favorites.toList()) { favorites.toSet() }
    val visible = remember(search, apps, onlyFavorites, favoriteSet) {
        apps.filter { it.label.contains(search, ignoreCase = true) && (!onlyFavorites || it.packageName in favoriteSet) }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp).padding(top = 8.dp, bottom = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            TextButton(onClick = onBack) { Text("←", color = accent, fontSize = 26.sp) }
            Column(Modifier.weight(1f)) {
                Text("Приложения", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                Text("${apps.size} установлено", color = WhiteMuted, fontSize = 11.sp)
            }
            TextButton(onClick = onEdit) {
                Text(if (editing) "Готово" else "Изменить", fontSize = 12.sp, color = accent)
            }
        }
        OutlinedTextField(
            value = search, onValueChange = onSearch, singleLine = true,
            placeholder = { Text("Быстрый поиск", color = WhiteMuted) },
            leadingIcon = { Text("⌕", color = accent, fontSize = 25.sp) },
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 10.dp),
            shape = RoundedCornerShape(19.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = accent.copy(alpha = .65f),
                unfocusedBorderColor = Color.White.copy(alpha = .12f),
                focusedContainerColor = Panel, unfocusedContainerColor = Panel
            )
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipItem("Все", selected = !onlyFavorites, accent = accent) { onlyFavorites = false }
            FilterChipItem("★ Избранное", selected = onlyFavorites, accent = accent) { onlyFavorites = true }
            Spacer(Modifier.weight(1f))
            Text("${visible.size}", fontSize = 12.sp, color = WhiteMuted)
        }
        if (editing) {
            Text("Нажми на приложение, чтобы добавить или убрать его из избранного",
                color = WhiteMuted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        }
        if (visible.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Ничего не найдено", color = WhiteMuted, fontSize = 14.sp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(columns), modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 20.dp)
            ) {
                items(visible, key = { it.packageName }) { app ->
                    AppShortcut(app, accent, editing, app.packageName in favoriteSet,
                        onLaunch = { onLaunch(app) }, onToggle = { onFavorite(app.packageName) })
                }
            }
        }
    }
}

@Composable
private fun FilterChipItem(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(13.dp)
    Box(Modifier.clip(shape)
        .background(if (selected) accent.copy(alpha = .19f) else Panel.copy(alpha = .75f))
        .border(1.dp, if (selected) accent.copy(alpha = .45f) else Color.White.copy(alpha = .07f), shape)
        .clickable(onClick = onClick)
        .padding(horizontal = 13.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (selected) accent else WhiteMuted, fontSize = 12.sp)
    }
}

@Composable
private fun NovaSettings(
    columns: Int, palette: Int, accent: Color,
    onColumns: (Int) -> Unit, onPalette: (Int) -> Unit,
    onBack: () -> Unit, onEditFavorites: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 27.sp, color = accent) }
            Text("Nova · Оформление", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(29.dp))
        Text("ЦВЕТОВАЯ ТЕМА", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(11.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            themes.forEachIndexed { index, color ->
                val selected = index == palette
                Column(Modifier.weight(1f).clip(RoundedCornerShape(17.dp))
                    .background(Panel)
                    .border(1.dp, if (selected) color else Color.White.copy(alpha = .09f), RoundedCornerShape(17.dp))
                    .clickable { onPalette(index) }
                    .padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(32.dp).clip(CircleShape).background(color))
                    Spacer(Modifier.height(11.dp))
                    Text(themeNames[index], color = if (selected) color else WhiteMuted, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(31.dp))
        Text("СЕТКА ПРИЛОЖЕНИЙ", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(13.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            listOf(3, 4, 5).forEach { value ->
                val chosen = columns == value
                Box(Modifier.weight(1f).clip(RoundedCornerShape(13.dp))
                    .background(if (chosen) accent.copy(alpha = .15f) else Panel)
                    .border(1.dp, if (chosen) accent else Color.White.copy(alpha = .09f), RoundedCornerShape(13.dp))
                    .clickable { onColumns(value) }.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    Text("$value", color = if (chosen) accent else WhiteMuted, fontSize = 16.sp)
                }
            }
        }
        Spacer(Modifier.height(30.dp))
        Button(onClick = onEditFavorites, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
            Text("Настроить избранное")
        }
        Spacer(Modifier.height(19.dp))
        Text("Nova Mobile 0.3 · Visual Preview", color = WhiteMuted, fontSize = 12.sp)
        Spacer(Modifier.height(7.dp))
        Text("Запуск приложений и быстрый кэш иконок сохранены. One UI Home остаётся установленным. Перемещение плиток жестом пока не реализовано.",
            color = Color.White.copy(alpha = .43f), fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun AppShortcut(
    app: InstalledApp,
    accent: Color,
    editing: Boolean,
    favorite: Boolean,
    onLaunch: () -> Unit,
    onToggle: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().height(91.dp).clip(RoundedCornerShape(15.dp))
            .clickable { if (editing) onToggle() else onLaunch() }
            .padding(top = 5.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            AppIcon(app, 51)
            if (editing) {
                Box(Modifier.size(19.dp).clip(CircleShape)
                    .background(if (favorite) accent else Color(0xFF46485A)),
                    contentAlignment = Alignment.Center) {
                    Text(if (favorite) "✓" else "+", fontSize = 12.sp, color = Background)
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(app.label, color = Color.White.copy(alpha = .91f), fontSize = 11.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 1.dp))
    }
}

// Icons are expensive to inflate/render on Android. Never do that during Compose
// item composition or scrolling; decode off the main thread and reuse bitmaps.
private object AppIconCache {
    // About 16 MiB, enough for roughly 190 icons at 144x144 ARGB_8888.
    private val images = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int =
            ((value.byteCount.toLong() + 1023L) / 1024L).toInt()
    }

    // Fast flings can bring dozens of icons into view. Bound concurrent work.
    private val parallelism = Semaphore(3)

    fun peek(key: String): Bitmap? = synchronized(images) { images.get(key) }

    suspend fun load(pm: PackageManager, app: InstalledApp, key: String): Bitmap? {
        peek(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            parallelism.withPermit {
                peek(key) ?: runCatching {
                    val component = ComponentName(app.packageName, app.activityName)
                    drawableAsBitmap(pm.getActivityIcon(component))
                }.getOrNull()?.also { result ->
                    synchronized(images) { images.put(key, result) }
                }
            }
        }
    }
}

@Composable
private fun AppIcon(app: InstalledApp, size: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val key = remember(app.packageName, app.activityName) {
        "${app.packageName}/${app.activityName}"
    }
    val cached = remember(key) { AppIconCache.peek(key) }
    val bitmap by produceState<Bitmap?>(initialValue = cached, key1 = key) {
        if (value == null) {
            value = AppIconCache.load(context.packageManager, app, key)
        }
    }
    val image = remember(bitmap) { bitmap?.asImageBitmap() }
    Box(modifier.size(size.dp), contentAlignment = Alignment.Center) {
        if (image != null) {
            Image(bitmap = image, contentDescription = app.label, modifier = Modifier.fillMaxSize())
        } else {
            Box(
                Modifier.fillMaxSize().clip(RoundedCornerShape(15.dp)).background(Panel),
                contentAlignment = Alignment.Center
            ) { Text(app.label.take(1).uppercase(), color = Purple, fontSize = 22.sp) }
        }
    }
}

private fun drawableAsBitmap(drawable: Drawable): Bitmap {
    val target = 144
    val bitmap = Bitmap.createBitmap(target, target, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val icon = drawable.constantState?.newDrawable()?.mutate() ?: drawable.mutate()
    icon.setBounds(0, 0, target, target)
    icon.draw(canvas)
    return bitmap
}
