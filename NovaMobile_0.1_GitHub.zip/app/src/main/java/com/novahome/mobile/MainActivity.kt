package com.novahome.mobile

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF07080E)
private val Tile = Color(0xFF191B2B)
private val Violet = Color(0xFFB99AFF)

data class InstalledApp(val label: String, val packageName: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("nova", MODE_PRIVATE)
        val pm = packageManager
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { InstalledApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
        setContent {
            var search by remember { mutableStateOf("") }
            var edit by remember { mutableStateOf(false) }
            var columns by remember { mutableIntStateOf(prefs.getInt("columns", 4)) }
            var accent by remember { mutableStateOf(prefs.getBoolean("purple", true)) }
            val color = if (accent) Violet else Color(0xFF72E1D1)
            val favorites = remember { mutableStateListOf<String>().apply { addAll(prefs.getString("favorites", "")!!.split("|").filter { it.isNotBlank() }) } }
            fun saveFavorites() { prefs.edit().putString("favorites", favorites.joinToString("|")).apply() }
            fun launch(pkg: String) { pm.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } }
            Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 20.dp, vertical = 24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("NOVA", color = color, fontSize = 30.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                    TextButton(onClick = { edit = !edit }) { Text(if (edit) "Готово" else "Настроить", color = color) }
                }
                Text("Твой экран. Твои правила.", color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.height(28.dp))
                if (edit) {
                    Text("Колонки: $columns", color = Color.White)
                    Row { listOf(3,4,5).forEach { n -> TextButton(onClick = { columns=n; prefs.edit().putInt("columns", n).apply() }) { Text("$n", color = if(columns==n) color else Color.Gray) } } }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Фиолетовый акцент", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = accent, onCheckedChange = { accent=it; prefs.edit().putBoolean("purple", it).apply() })
                    }
                }
                Text("ИЗБРАННОЕ", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                val pinned = apps.filter { it.packageName in favorites }
                if (pinned.isEmpty()) Text("Нажми + у приложения ниже, чтобы закрепить его", color = Color.Gray, fontSize = 12.sp)
                else LazyVerticalGrid(columns = GridCells.Fixed(columns), modifier = Modifier.heightIn(max = 190.dp)) {
                    items(pinned) { app -> AppTile(app, color, edit, true, { launch(app.packageName) }) { favorites.remove(app.packageName); saveFavorites() } }
                }
                Spacer(Modifier.height(24.dp))
                Text("ВСЕ ПРИЛОЖЕНИЯ", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                BasicTextField(value = search, onValueChange = { search=it }, singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp),
                    decorationBox = { inner -> Box(Modifier.fillMaxWidth().background(Tile, RoundedCornerShape(14.dp)).padding(14.dp)) {
                        if (search.isEmpty()) Text("Поиск приложений…", color = Color.Gray)
                        inner()
                    } })
                Spacer(Modifier.height(14.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(columns), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(apps.filter { it.label.contains(search, true) }) { app ->
                        AppTile(app, color, edit, app.packageName in favorites, { launch(app.packageName) }) {
                            if (app.packageName in favorites) favorites.remove(app.packageName) else favorites.add(app.packageName)
                            saveFavorites()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppTile(app: InstalledApp, accent: Color, editing: Boolean, favorite: Boolean, onLaunch: () -> Unit, onToggle: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Tile, RoundedCornerShape(16.dp)).clickable { if (editing) onToggle() else onLaunch() }.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(38.dp).background(accent.copy(alpha=.15f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text(app.label.take(1).uppercase(), color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Text(app.label, color = Color.White, fontSize = 11.sp, maxLines = 2, lineHeight = 13.sp)
        if (editing) Text(if (favorite) "−" else "+", color = accent, fontSize = 20.sp)
    }
}
