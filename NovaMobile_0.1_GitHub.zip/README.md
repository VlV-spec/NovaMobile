# Nova Mobile 0.4 — Home Editor Preview

Test build of a persistent home-shortcut placement editor.

- Tap **Расставить** on home screen, tap a shortcut and then its destination; the two entries swap. Works between dock and home grid. Changes persist to SharedPreferences.
- Tap the selected shortcut again to cancel selection, or **Готово** to finish.
- The Settings screen can hide or restore the large clock widget.
- Retains app launch, search, three themes, 3/4/5 columns, saved favorites, asynchronous icon load and 16 MiB LRU.
- Separate install package com.novahome.mobile.editorpreview. No dangerous permissions.
- This is TAP-TO-SWAP editing, not drag-and-drop yet.
- Known caveat: debug APK signed by each GitHub Actions runner may not be upgradable in place.
