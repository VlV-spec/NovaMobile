# Nova Mobile 0.3 Visual Preview

A visual polish iteration based on verified 0.2.1 Performance Preview.

- Keeps the same asynchronous icon rendering, concurrency-limited bitmap decode, and 16 MiB icon LRU cache.
- Redesigned AMOLED home with polished clock/date card, local battery indicator, quick launch actions, and compact dock.
- App drawer: favorite-only filter, count, compact list, search, editable favorites.
- Three selectable color palettes: Violet, Arctic, Rose, stored in SharedPreferences.
- Android Back returns to home from app drawer or settings.
- Separate Android package `com.novahome.mobile.visualpreview`, so stable 0.2.1 is untouched.
- No new dangerous permissions, ads, tracking, or background services.

Build with Gradle 8.9 and Java 17, `gradle :app:assembleDebug`. GitHub Actions expects the entire project zipped as `NovaMobile_0.1_GitHub.zip` in the repository root.

Testing priority: first scroll/repeated scroll, launching apps, editing favorites, palette changes, orientation/window insets, Back navigation, battery indicator.
