# Nova Mobile 0.2.1 Performance Preview

Performance-only patch based on the working 0.2 build.

- Offloads Android drawable inflation / bitmap creation off the Compose main thread.
- Keeps a bounded 16 MiB LRU cache of app icon bitmaps across LazyVerticalGrid item recycling.
- Limits icon decode concurrency to three background jobs.
- Retains launch behavior, app search, favorites, drawer, dock, accent settings.
- Uses package `com.novahome.mobile.preview` and label `Nova Mobile Preview`, so it installs **alongside** the current 0.2 app and does not overwrite your settings or launcher choice.
- The first scroll may show letter placeholders briefly while icons load; subsequent scrolling uses cached images.

## CI

Existing GitHub Actions workflow expects `NovaMobile_0.1_GitHub.zip` in repository root. Upload the replacement ZIP from this release with exactly that filename. GitHub Actions then produces a debug APK under Artifacts.

Note: a successful GitHub compilation is still needed; no local Android SDK is available for validating this preview APK.
