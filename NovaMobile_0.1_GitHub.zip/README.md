# Nova Mobile 0.2 (prototype)

Kotlin + Jetpack Compose home launcher for Samsung Galaxy S24 Ultra.

New in 0.2:
- Actual app icons via PackageManager, with letter fallback.
- Separate home screen, app drawer and settings screen.
- Live clock, date, favorites and bottom dock.
- Search, launch apps, configure 3/4/5 columns and accent color.
- Existing favorite preferences are preserved from version 0.1.

Not yet supported: true Android widgets, drag-and-drop editor, AI, gestures, TCL integration.

This is source code, not a compiled APK. CI build/runtime are not yet verified for 0.2.
Keep standard One UI Home installed while testing.
